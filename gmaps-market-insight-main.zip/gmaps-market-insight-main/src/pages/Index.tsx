import { useState, useMemo, useRef } from "react";
import { SearchForm } from "@/components/SearchForm";
import { ResultsTable } from "@/components/ResultsTable";
import { AdvancedFilters, FilterOptions } from "@/components/AdvancedFilters";
import { AnalyticsChart } from "@/components/AnalyticsChart";
import { SearchHistory } from "@/components/SearchHistory";
import { BookmarkManager } from "@/components/BookmarkManager";
import { ExportOptions } from "@/components/ExportOptions";
import { DarkModeToggle } from "@/components/DarkModeToggle";
import { TutorialOverlay } from "@/components/TutorialOverlay";
import { MapVisualization } from "@/components/MapVisualization";
import { CompetitorComparison } from "@/components/CompetitorComparison";
import { APIQuotaTracker } from "@/components/APIQuotaTracker";
import { KeyboardShortcuts } from "@/components/KeyboardShortcuts";
import { BatchSearch } from "@/components/BatchSearch";
import { MobileFilterSheet } from "@/components/MobileFilterSheet";
import { PDFExport } from "@/components/PDFExport";
import { TrendAnalysis } from "@/components/TrendAnalysis";
import { FolderManager } from "@/components/FolderManager";
import { AdvancedFavorites } from "@/components/AdvancedFavorites";
import { AIInsights } from "@/components/AIInsights";
import { PWAInstallPrompt } from "@/components/PWAInstallPrompt";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { MapPin, TrendingUp, Table2, RefreshCw, Map, Activity, Brain } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface ScrapingResult {
  id: string;
  name: string;
  address: string;
  website: string;
  phone: string;
  reviewCount: number;
  rating: number;
  category: string;
}

const Index = () => {
  const { toast } = useToast();
  const [results, setResults] = useState<ScrapingResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastSearchData, setLastSearchData] = useState<any>(null);
  const [retryCount, setRetryCount] = useState(0);
  const [selectedResults, setSelectedResults] = useState<string[]>([]);
  const searchFormRef = useRef<HTMLDivElement>(null);
  const exportRef = useRef<any>(null);
  const [filters, setFilters] = useState<FilterOptions>({
    minRating: 0,
    minReviews: 0,
    hasWebsite: "all",
    category: "all",
    searchTerm: "",
  });

  // Get unique categories from results
  const categories = useMemo(() => {
    const uniqueCategories = [...new Set(results.map(r => r.category))];
    return uniqueCategories.sort();
  }, [results]);

  // Apply filters to results
  const filteredResults = useMemo(() => {
    return results.filter(result => {
      // Search term filter
      if (filters.searchTerm) {
        const searchLower = filters.searchTerm.toLowerCase();
        const matchesSearch = 
          result.name.toLowerCase().includes(searchLower) ||
          result.address.toLowerCase().includes(searchLower);
        if (!matchesSearch) return false;
      }

      // Rating filter
      if (result.rating < filters.minRating) return false;

      // Review count filter
      if (result.reviewCount < filters.minReviews) return false;

      // Website filter
      if (filters.hasWebsite === "yes" && (result.website === "-" || !result.website)) return false;
      if (filters.hasWebsite === "no" && result.website && result.website !== "-") return false;

      // Category filter
      if (filters.category !== "all" && result.category !== filters.category) return false;

      return true;
    });
  }, [results, filters]);

  const handleSearch = async (searchData: {
    keyword: string;
    province: string;
    city: string;
    district: string;
    apiKey: string;
  }, isRetry = false) => {
    setIsLoading(true);
    setResults([]);
    if (!isRetry) {
      setLastSearchData(searchData);
      setRetryCount(0);
    }
    
    try {
      console.log('Calling backend function with search data:', searchData);
      
      const { data, error } = await supabase.functions.invoke('google-maps-scraper', {
        body: searchData
      });

      if (error) {
        console.error('Function error:', error);
        
        // Retry mechanism with exponential backoff
        if (!isRetry && retryCount < 2) {
          const delay = Math.pow(2, retryCount) * 1000;
          toast({
            title: "Mencoba Ulang...",
            description: `Retry attempt ${retryCount + 1}/2 dalam ${delay/1000} detik`,
          });
          
          await new Promise(resolve => setTimeout(resolve, delay));
          setRetryCount(prev => prev + 1);
          return handleSearch(searchData, true);
        }
        
        throw error;
      }

      console.log('Backend response:', data);

      if (data.error) {
        // Better error messages dengan actionable steps
        let errorDescription = data.details || "Terjadi kesalahan saat melakukan scraping";
        let actionableSteps = "";
        
        if (data.error.includes("API Key")) {
          actionableSteps = "\n\nLangkah:\n1. Periksa API key di SerpAPI dashboard\n2. Pastikan key masih aktif\n3. Copy-paste ulang dengan hati-hati";
        } else if (data.error.includes("Quota")) {
          actionableSteps = "\n\nLangkah:\n1. Tunggu hingga bulan depan untuk reset\n2. Atau upgrade plan di SerpAPI\n3. Gunakan API key berbeda jika ada";
        }

        toast({
          title: data.error,
          description: errorDescription + actionableSteps,
          variant: "destructive",
          duration: 10000,
        });
        throw new Error(data.error);
      }

      if (data.results && data.results.length > 0) {
        setResults(data.results);
        
        // Dispatch event for quota tracker
        window.dispatchEvent(new Event('search-completed'));
        
        toast({
          title: "Scraping Berhasil!",
          description: `${data.results.length} bisnis berhasil di-scrape`,
        });
        
        // Save to database for history
        try {
          const { data: historyData, error: historyError } = await supabase
            .from('search_history')
            .insert({
              keyword: searchData.keyword,
              province: searchData.province,
              city: searchData.city,
              district: searchData.district || null,
              results_count: data.results.length,
            })
            .select()
            .single();

          if (historyError) {
            console.error('Error saving search history:', historyError);
          } else if (historyData) {
            // Save individual results
            const resultsToSave = data.results.map((result: ScrapingResult) => ({
              search_id: historyData.id,
              place_id: result.id,
              name: result.name,
              address: result.address,
              website: result.website,
              phone: result.phone,
              review_count: result.reviewCount,
              rating: result.rating,
              category: result.category,
            }));

            const { error: resultsError } = await supabase
              .from('scraping_results')
              .insert(resultsToSave);

            if (resultsError) {
              console.error('Error saving scraping results:', resultsError);
            }
          }
        } catch (dbError) {
          console.error('Database error:', dbError);
        }
      } else {
        setResults([]);
        toast({
          title: "Tidak Ada Hasil",
          description: "Coba dengan keyword atau lokasi berbeda",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error('Error during scraping:', error);
      
      // Network error handling
      if (error.message?.includes('fetch')) {
        toast({
          title: "Koneksi Terputus",
          description: "Periksa koneksi internet Anda dan coba lagi",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Gagal Scraping",
          description: error.message || "Terjadi kesalahan. Coba lagi dalam beberapa saat.",
          variant: "destructive",
        });
      }
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = () => {
    if (lastSearchData) {
      toast({
        title: "Refresh Pencarian",
        description: "Mengulangi pencarian terakhir...",
      });
      handleSearch(lastSearchData);
    } else {
      toast({
        title: "Tidak Ada Pencarian",
        description: "Belum ada pencarian sebelumnya untuk direfresh",
        variant: "destructive",
      });
    }
  };

  const handleLoadHistory = async (historyItem: any) => {
    try {
      const { data, error } = await supabase
        .from('scraping_results')
        .select('*')
        .eq('search_id', historyItem.id);

      if (error) throw error;

      if (data && data.length > 0) {
        const loadedResults: ScrapingResult[] = data.map(item => ({
          id: item.place_id || item.id,
          name: item.name,
          address: item.address || '-',
          website: item.website || '-',
          phone: item.phone || '-',
          reviewCount: item.review_count || 0,
          rating: Number(item.rating) || 0,
          category: item.category || 'Tidak Tersedia',
        }));

        setResults(loadedResults);
        toast({
          title: "History Dimuat",
          description: `${loadedResults.length} hasil berhasil dimuat dari history`,
        });
      } else {
        toast({
          title: "Data Tidak Ditemukan",
          description: "Data history tidak dapat dimuat",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error loading history:', error);
      toast({
        title: "Gagal Memuat History",
        description: "Terjadi kesalahan saat memuat history",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/30">
      {/* Header with Enhanced Design */}
      <div className="border-b border-border/40 bg-card/80 backdrop-blur-md shadow-sm">
        <div className="container mx-auto px-4 py-5">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-primary via-primary to-accent flex items-center justify-center shadow-lg ring-2 ring-primary/20">
                <MapPin className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-primary via-primary to-accent bg-clip-text text-transparent">
                  Google Maps Scraper
                </h1>
                <p className="text-sm text-muted-foreground font-medium">
                  Riset Kompetitor & Analisis Market
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <DarkModeToggle />
              {lastSearchData && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRefresh}
                  disabled={isLoading}
                  className="gap-2"
                >
                  <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">Refresh</span>
                </Button>
              )}
              <CompetitorComparison results={filteredResults} />
              <FolderManager 
                selectedResults={results.filter(r => selectedResults.includes(r.id))}
                onMoveToFolder={() => setSelectedResults([])}
              />
              <AdvancedFavorites currentResults={results} />
              <BatchSearch 
                onSearch={handleSearch}
                lastSearchData={lastSearchData}
              />
              <PDFExport results={filteredResults} />
              <BookmarkManager 
                currentResults={results}
                onLoadBookmarks={setResults}
              />
              {results.length > 0 && (
                <ExportOptions results={filteredResults} />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid gap-6 lg:grid-cols-[420px_1fr]">
          {/* Left Sidebar */}
          <div className="space-y-6">
            <Card className="p-6 shadow-lg border-border/50 bg-card/80 backdrop-blur-sm" ref={searchFormRef}>
              <div className="flex items-center gap-2 mb-5">
                <div className="p-1.5 rounded-lg bg-primary/10">
                  <TrendingUp className="h-4 w-4 text-primary" />
                </div>
                <h2 className="text-lg font-semibold text-foreground">Parameter Pencarian</h2>
              </div>
              <SearchForm onSearch={handleSearch} isLoading={isLoading} />
            </Card>

            {/* API Quota Tracker */}
            <APIQuotaTracker />

            {/* Search History */}
            <SearchHistory onLoadHistory={handleLoadHistory} />

            {/* API Info Card with Enhanced Design */}
            <Card className="p-5 bg-gradient-to-br from-primary/8 to-accent/8 border-primary/20 shadow-md">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-1.5 rounded-lg bg-primary/10">
                  <Activity className="h-4 w-4 text-primary" />
                </div>
                <h3 className="font-semibold text-sm text-foreground">Rekomendasi API</h3>
              </div>
              <ul className="space-y-3 text-sm">
                <li className="flex items-start gap-3 p-3 rounded-lg bg-card/50 border border-border/30">
                  <span className="text-primary font-bold text-lg">•</span>
                  <div>
                    <span className="font-semibold text-foreground">SerpAPI</span>
                    <p className="text-muted-foreground text-xs mt-0.5">100 searches gratis/bulan</p>
                    <a 
                      href="https://serpapi.com/manage-api-key" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-primary hover:underline text-xs mt-2 font-medium"
                    >
                      Dapatkan API Key →
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-3 p-3 rounded-lg bg-card/50 border border-border/30">
                  <span className="text-accent font-bold text-lg">•</span>
                  <div>
                    <span className="font-semibold text-foreground">Free tier</span>
                    <p className="text-muted-foreground text-xs mt-0.5">Reset setiap bulan</p>
                  </div>
                </li>
              </ul>
            </Card>
          </div>

          {/* Results */}
          <div className="space-y-6">
            {/* Advanced Filters */}
            {results.length > 0 && (
              <div className="flex items-center gap-2">
                <div className="hidden md:block flex-1">
                  <AdvancedFilters 
                    onFilterChange={setFilters}
                    categories={categories}
                  />
                </div>
                <MobileFilterSheet
                  onFilterChange={setFilters}
                  categories={categories}
                />
              </div>
            )}

            {/* Tabs for Table, Analytics, Map, Trends, and AI */}
            {results.length > 0 ? (
              <>
                {/* Bulk Selection Indicator */}
                {selectedResults.length > 0 && (
                  <Card className="p-4 bg-primary/5 border-primary/20">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {selectedResults.length} items selected
                      </span>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedResults([])}
                        >
                          Clear Selection
                        </Button>
                      </div>
                    </div>
                  </Card>
                )}

                <Tabs defaultValue="table" className="w-full">
                  <TabsList className="grid w-full max-w-4xl grid-cols-5">
                    <TabsTrigger value="table" className="flex items-center gap-2">
                      <Table2 className="h-4 w-4" />
                      <span className="hidden sm:inline">Tabel</span>
                    </TabsTrigger>
                    <TabsTrigger value="analytics" className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4" />
                      <span className="hidden sm:inline">Analytics</span>
                    </TabsTrigger>
                    <TabsTrigger value="map" className="flex items-center gap-2">
                      <Map className="h-4 w-4" />
                      <span className="hidden sm:inline">Map</span>
                    </TabsTrigger>
                    <TabsTrigger value="trends" className="flex items-center gap-2">
                      <Activity className="h-4 w-4" />
                      <span className="hidden sm:inline">Trends</span>
                    </TabsTrigger>
                    <TabsTrigger value="ai" className="flex items-center gap-2">
                      <Brain className="h-4 w-4" />
                      <span className="hidden sm:inline">AI</span>
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="table" className="mt-6">
                    <ResultsTable 
                      results={filteredResults} 
                      isLoading={isLoading}
                      selectedResults={selectedResults}
                      onSelectionChange={setSelectedResults}
                    />
                  </TabsContent>
                  <TabsContent value="analytics" className="mt-6">
                    <AnalyticsChart results={filteredResults} />
                  </TabsContent>
                  <TabsContent value="map" className="mt-6">
                    <MapVisualization results={filteredResults} />
                  </TabsContent>
                  <TabsContent value="trends" className="mt-6">
                    <TrendAnalysis />
                  </TabsContent>
                  <TabsContent value="ai" className="mt-6">
                    <AIInsights results={filteredResults} />
                  </TabsContent>
                </Tabs>
              </>
            ) : (
              <ResultsTable 
                results={[]} 
                isLoading={isLoading}
                selectedResults={selectedResults}
                onSelectionChange={setSelectedResults}
              />
            )}
          </div>
        </div>
      </div>

      {/* Tutorial Overlay */}
      <TutorialOverlay />
      
      {/* PWA Install Prompt */}
      <PWAInstallPrompt />
      
      {/* Keyboard Shortcuts */}
      <KeyboardShortcuts
        onSearch={() => searchFormRef.current?.scrollIntoView({ behavior: 'smooth' })}
        onExport={() => exportRef.current?.click()}
        onFilter={() => {}}
        onRefresh={handleRefresh}
      />
    </div>
  );
};

export default Index;
