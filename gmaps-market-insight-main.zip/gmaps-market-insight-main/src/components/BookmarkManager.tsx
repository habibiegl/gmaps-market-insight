import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bookmark, Star, Trash2, Download } from "lucide-react";
import { ScrapingResult } from "@/pages/Index";
import { useToast } from "@/hooks/use-toast";
import * as XLSX from "xlsx";

interface BookmarkManagerProps {
  currentResults: ScrapingResult[];
  onLoadBookmarks: (results: ScrapingResult[]) => void;
}

export const BookmarkManager = ({ currentResults, onLoadBookmarks }: BookmarkManagerProps) => {
  const { toast } = useToast();
  const [bookmarks, setBookmarks] = useState<ScrapingResult[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    loadBookmarks();
  }, []);

  const loadBookmarks = () => {
    const saved = localStorage.getItem('scraping_bookmarks');
    if (saved) {
      setBookmarks(JSON.parse(saved));
    }
  };

  const saveBookmarks = (newBookmarks: ScrapingResult[]) => {
    localStorage.setItem('scraping_bookmarks', JSON.stringify(newBookmarks));
    setBookmarks(newBookmarks);
  };

  const addBookmark = (result: ScrapingResult) => {
    const exists = bookmarks.find(b => b.id === result.id);
    if (exists) {
      toast({
        title: "Sudah Ada",
        description: "Bisnis ini sudah ada di bookmark",
        variant: "destructive",
      });
      return;
    }

    const newBookmarks = [...bookmarks, result];
    saveBookmarks(newBookmarks);
    toast({
      title: "Bookmark Ditambahkan",
      description: `${result.name} ditambahkan ke bookmark`,
    });
  };

  const removeBookmark = (id: string) => {
    const newBookmarks = bookmarks.filter(b => b.id !== id);
    saveBookmarks(newBookmarks);
    toast({
      title: "Bookmark Dihapus",
      description: "Bookmark berhasil dihapus",
    });
  };

  const exportBookmarks = () => {
    if (bookmarks.length === 0) {
      toast({
        title: "Tidak Ada Data",
        description: "Belum ada bookmark untuk diexport",
        variant: "destructive",
      });
      return;
    }

    const worksheet = XLSX.utils.json_to_sheet(
      bookmarks.map((result) => ({
        Nama: result.name,
        Alamat: result.address,
        "Situs Web": result.website,
        Telepon: result.phone,
        "Jumlah Ulasan": result.reviewCount,
        "Rating Rata-Rata": result.rating,
        Kategori: result.category,
      }))
    );

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Bookmarks");
    XLSX.writeFile(workbook, `bookmarks-${Date.now()}.xlsx`);

    toast({
      title: "Export Berhasil",
      description: `${bookmarks.length} bookmark berhasil diexport`,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Bookmark className="h-4 w-4" />
          Bookmark ({bookmarks.length})
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Bookmark Manager</span>
            {bookmarks.length > 0 && (
              <Button variant="ghost" size="sm" onClick={exportBookmarks}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            )}
          </DialogTitle>
          <DialogDescription>
            Kelola dan export bisnis yang sudah di-bookmark
          </DialogDescription>
        </DialogHeader>

        {bookmarks.length === 0 ? (
          <div className="text-center py-12">
            <Bookmark className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">Belum ada bookmark</p>
            <p className="text-sm text-muted-foreground mt-2">
              Klik tombol bookmark di hasil pencarian untuk menyimpan
            </p>
          </div>
        ) : (
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-3">
              {bookmarks.map((bookmark) => (
                <div
                  key={bookmark.id}
                  className="p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium truncate">{bookmark.name}</h4>
                      <p className="text-sm text-muted-foreground truncate mt-1">
                        {bookmark.address}
                      </p>
                      <div className="flex items-center gap-4 mt-2">
                        <div className="flex items-center gap-1">
                          <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium">{bookmark.rating}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {bookmark.reviewCount.toLocaleString()} ulasan
                        </span>
                        <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                          {bookmark.category}
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => removeBookmark(bookmark.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}

        {currentResults.length > 0 && (
          <div className="border-t pt-4">
            <p className="text-sm text-muted-foreground mb-2">
              Tambah dari hasil pencarian saat ini:
            </p>
            <div className="flex gap-2 flex-wrap">
              {currentResults.slice(0, 5).map((result) => (
                <Button
                  key={result.id}
                  variant="outline"
                  size="sm"
                  onClick={() => addBookmark(result)}
                  disabled={bookmarks.some(b => b.id === result.id)}
                >
                  <Bookmark className="h-3 w-3 mr-1" />
                  {result.name.slice(0, 20)}...
                </Button>
              ))}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
