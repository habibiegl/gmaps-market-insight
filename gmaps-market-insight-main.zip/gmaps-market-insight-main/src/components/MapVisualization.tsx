import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, Navigation, Loader2 } from "lucide-react";
import { ScrapingResult } from "@/pages/Index";
import { useToast } from "@/hooks/use-toast";

interface MapVisualizationProps {
  results: ScrapingResult[];
}

export const MapVisualization = ({ results }: MapVisualizationProps) => {
  const { toast } = useToast();
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<any>(null);
  const [mapboxToken, setMapboxToken] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [mapLoaded, setMapLoaded] = useState(false);

  useEffect(() => {
    const savedToken = localStorage.getItem('mapbox_token');
    if (savedToken) {
      setMapboxToken(savedToken);
      initializeMap(savedToken);
    }
  }, []);

  useEffect(() => {
    if (mapLoaded && results.length > 0) {
      addMarkersToMap();
    }
  }, [results, mapLoaded]);

  const initializeMap = async (token: string) => {
    if (!mapContainer.current || map.current) return;

    setIsLoading(true);
    try {
      // Dynamically import mapbox-gl
      const mapboxgl = (await import('mapbox-gl')).default;
      await import('mapbox-gl/dist/mapbox-gl.css');

      mapboxgl.accessToken = token;

      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/streets-v12',
        center: [106.8456, -6.2088], // Jakarta default
        zoom: 12,
      });

      map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');

      map.current.on('load', () => {
        setMapLoaded(true);
        setIsLoading(false);
        toast({
          title: "Map Loaded",
          description: "Peta berhasil dimuat",
        });
      });

    } catch (error) {
      console.error('Error loading map:', error);
      setIsLoading(false);
      toast({
        title: "Error Loading Map",
        description: "Gagal memuat peta. Periksa Mapbox token Anda.",
        variant: "destructive",
      });
    }
  };

  const addMarkersToMap = async () => {
    if (!map.current || results.length === 0) return;

    const mapboxgl = (await import('mapbox-gl')).default;

    // Remove existing markers
    const markers = document.querySelectorAll('.mapboxgl-marker');
    markers.forEach(marker => marker.remove());

    // Geocode and add markers for each result
    results.forEach(async (result, index) => {
      try {
        // Use Mapbox Geocoding API
        const geocodeUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(result.address)}.json?access_token=${mapboxToken}&country=ID`;
        const response = await fetch(geocodeUrl);
        const data = await response.json();

        if (data.features && data.features.length > 0) {
          const [lng, lat] = data.features[0].center;

          // Create custom marker
          const markerEl = document.createElement('div');
          markerEl.className = 'custom-marker';
          markerEl.style.width = '30px';
          markerEl.style.height = '30px';
          markerEl.style.borderRadius = '50%';
          markerEl.style.backgroundColor = '#3b82f6';
          markerEl.style.border = '3px solid white';
          markerEl.style.cursor = 'pointer';
          markerEl.style.boxShadow = '0 2px 4px rgba(0,0,0,0.3)';

          // Create popup
          const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(`
            <div style="padding: 8px;">
              <h3 style="font-weight: bold; margin-bottom: 4px;">${result.name}</h3>
              <p style="font-size: 12px; color: #666; margin-bottom: 4px;">${result.address}</p>
              <div style="display: flex; align-items: center; gap: 8px; margin-top: 8px;">
                <span style="display: flex; align-items: center; gap: 2px;">
                  <span style="color: #fbbf24;">★</span>
                  <strong>${result.rating}</strong>
                </span>
                <span style="font-size: 12px; color: #666;">${result.reviewCount} ulasan</span>
              </div>
              ${result.website && result.website !== '-' ? 
                `<a href="${result.website}" target="_blank" style="color: #3b82f6; font-size: 12px; margin-top: 8px; display: block;">Buka Website →</a>` 
                : ''}
            </div>
          `);

          // Add marker to map
          new mapboxgl.Marker(markerEl)
            .setLngLat([lng, lat])
            .setPopup(popup)
            .addTo(map.current);

          // Fit bounds to show all markers
          if (index === results.length - 1) {
            const bounds = new mapboxgl.LngLatBounds();
            results.forEach(() => {
              if (data.features[0]) {
                bounds.extend(data.features[0].center);
              }
            });
            map.current.fitBounds(bounds, { padding: 50 });
          }
        }
      } catch (error) {
        console.error('Error geocoding address:', error);
      }
    });
  };

  const handleSaveToken = () => {
    if (!mapboxToken.trim()) {
      toast({
        title: "Token Required",
        description: "Masukkan Mapbox token terlebih dahulu",
        variant: "destructive",
      });
      return;
    }

    localStorage.setItem('mapbox_token', mapboxToken);
    initializeMap(mapboxToken);
  };

  if (!mapboxToken || !mapLoaded) {
    return (
      <Card className="p-6">
        <div className="text-center space-y-4">
          <MapPin className="h-12 w-12 mx-auto text-muted-foreground" />
          <h3 className="text-lg font-semibold">Map Visualization</h3>
          <p className="text-sm text-muted-foreground">
            Untuk menggunakan fitur map, masukkan Mapbox Access Token Anda
          </p>
          <div className="max-w-md mx-auto space-y-3">
            <Input
              type="text"
              placeholder="Masukkan Mapbox Token"
              value={mapboxToken}
              onChange={(e) => setMapboxToken(e.target.value)}
            />
            <Button onClick={handleSaveToken} disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Loading Map...
                </>
              ) : (
                <>
                  <MapPin className="h-4 w-4 mr-2" />
                  Load Map
                </>
              )}
            </Button>
            <p className="text-xs text-muted-foreground">
              Dapatkan token gratis di{" "}
              <a
                href="https://account.mapbox.com/access-tokens/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                Mapbox.com
              </a>
            </p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-0 overflow-hidden">
      <div className="p-4 border-b flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Navigation className="h-5 w-5 text-primary" />
          <h3 className="font-semibold">Map Visualization</h3>
        </div>
        <span className="text-sm text-muted-foreground">
          {results.length} lokasi
        </span>
      </div>
      <div ref={mapContainer} className="w-full h-[600px]" />
    </Card>
  );
};
