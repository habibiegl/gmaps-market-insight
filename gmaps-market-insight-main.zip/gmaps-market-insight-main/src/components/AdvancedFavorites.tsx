import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Star, TrendingUp, AlertCircle, CheckCircle, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ScrapingResult } from "@/pages/Index";

interface AdvancedFavoritesProps {
  currentResults: ScrapingResult[];
}

interface FavoriteType {
  id: string;
  place_id: string;
  name: string;
  address: string;
  rating: number;
  review_count: number;
  category: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'new' | 'contacted' | 'interested' | 'closed' | 'archived';
  favorited_at: string;
  last_contacted: string | null;
  leadScore?: number;
}

export const AdvancedFavorites = ({ currentResults }: AdvancedFavoritesProps) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [favorites, setFavorites] = useState<FavoriteType[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterPriority, setFilterPriority] = useState<string>("all");

  useEffect(() => {
    if (open) {
      loadFavorites();
    }
  }, [open]);

  const loadFavorites = async () => {
    try {
      const { data, error } = await supabase
        .from('favorites')
        .select('*')
        .order('favorited_at', { ascending: false });

      if (error) throw error;

      // Calculate lead scores
      const favoritesWithScores = (data || []).map(fav => ({
        ...fav,
        priority: fav.priority as 'low' | 'medium' | 'high' | 'urgent',
        status: fav.status as 'new' | 'contacted' | 'interested' | 'closed' | 'archived',
        leadScore: calculateLeadScore(fav),
      }));

      setFavorites(favoritesWithScores);
    } catch (error) {
      console.error('Error loading favorites:', error);
    }
  };

  const calculateLeadScore = (fav: any): number => {
    let score = 0;
    
    // Rating contribution (0-30 points)
    score += (fav.rating / 5) * 30;
    
    // Review count contribution (0-25 points)
    const reviewScore = Math.min(fav.review_count / 100, 1) * 25;
    score += reviewScore;
    
    // Has website (20 points)
    if (fav.address && fav.address !== '-') score += 15;
    
    // Priority contribution (0-15 points)
    const priorityScores = { urgent: 15, high: 10, medium: 5, low: 0 };
    score += priorityScores[fav.priority as keyof typeof priorityScores] || 0;
    
    // Status contribution (0-10 points)
    const statusScores = { new: 10, contacted: 7, interested: 5, closed: 0, archived: 0 };
    score += statusScores[fav.status as keyof typeof statusScores] || 0;

    return Math.round(score);
  };

  const addToFavorites = async (result: ScrapingResult, priority: string = 'medium') => {
    try {
      const { error } = await supabase
        .from('favorites')
        .insert([{
          place_id: result.id,
          name: result.name,
          address: result.address,
          rating: result.rating,
          review_count: result.reviewCount,
          category: result.category,
          priority,
          status: 'new',
        }]);

      if (error) throw error;

      toast({
        title: "Added to Favorites",
        description: `${result.name} ditambahkan ke favorites`,
      });

      loadFavorites();
    } catch (error: any) {
      if (error.code === '23505') {
        toast({
          title: "Already in Favorites",
          description: "Bisnis ini sudah ada di favorites",
          variant: "destructive",
        });
      }
    }
  };

  const updateFavoriteStatus = async (id: string, status: string) => {
    try {
      const updateData: any = { status };
      if (status === 'contacted') {
        updateData.last_contacted = new Date().toISOString();
      }

      const { error } = await supabase
        .from('favorites')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Status Updated",
        description: "Status berhasil diupdate",
      });

      loadFavorites();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const updateFavoritePriority = async (id: string, priority: string) => {
    try {
      const { error } = await supabase
        .from('favorites')
        .update({ priority })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Priority Updated",
        description: "Prioritas berhasil diupdate",
      });

      loadFavorites();
    } catch (error) {
      console.error('Error updating priority:', error);
    }
  };

  const filteredFavorites = favorites.filter(fav => {
    if (filterStatus !== 'all' && fav.status !== filterStatus) return false;
    if (filterPriority !== 'all' && fav.priority !== filterPriority) return false;
    return true;
  });

  const getPriorityColor = (priority: string) => {
    const colors = {
      urgent: 'bg-red-500',
      high: 'bg-orange-500',
      medium: 'bg-blue-500',
      low: 'bg-gray-500',
    };
    return colors[priority as keyof typeof colors] || 'bg-gray-500';
  };

  const getStatusIcon = (status: string) => {
    const icons = {
      new: <AlertCircle className="h-4 w-4" />,
      contacted: <Clock className="h-4 w-4" />,
      interested: <TrendingUp className="h-4 w-4" />,
      closed: <CheckCircle className="h-4 w-4" />,
      archived: <Star className="h-4 w-4" />,
    };
    return icons[status as keyof typeof icons] || <AlertCircle className="h-4 w-4" />;
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Star className="h-4 w-4" />
          Favorites ({favorites.length})
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Advanced Favorites & Lead Management</DialogTitle>
          <DialogDescription>
            Kelola lead dan track progress dengan lead scoring
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Filters */}
          <div className="flex gap-3">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="contacted">Contacted</SelectItem>
                <SelectItem value="interested">Interested</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Add from Current Results */}
          {currentResults.length > 0 && (
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm mb-2">Quick add from current results:</p>
              <div className="flex gap-2 flex-wrap">
                {currentResults.slice(0, 3).map((result) => (
                  <Button
                    key={result.id}
                    variant="outline"
                    size="sm"
                    onClick={() => addToFavorites(result, 'medium')}
                  >
                    <Star className="h-3 w-3 mr-1" />
                    {result.name.slice(0, 20)}...
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Favorites List */}
          <ScrollArea className="h-[500px]">
            {filteredFavorites.length === 0 ? (
              <div className="text-center py-12">
                <Star className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Belum ada favorites</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredFavorites.map((fav) => (
                  <div key={fav.id} className="p-4 rounded-lg border hover:bg-muted/50">
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-medium">{fav.name}</h4>
                          <div className={`h-2 w-2 rounded-full ${getPriorityColor(fav.priority)}`} />
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-1">
                          {fav.address}
                        </p>
                        <div className="flex items-center gap-3 mt-2">
                          <span className="text-sm flex items-center gap-1">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            {fav.rating}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {fav.review_count} reviews
                          </span>
                          <Badge variant="secondary">{fav.category}</Badge>
                        </div>
                      </div>
                      
                      {/* Lead Score */}
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary">
                          {fav.leadScore}
                        </div>
                        <p className="text-xs text-muted-foreground">Lead Score</p>
                      </div>
                    </div>

                    {/* Status & Priority Controls */}
                    <div className="flex gap-2 flex-wrap">
                      <Select value={fav.status} onValueChange={(val) => updateFavoriteStatus(fav.id, val)}>
                        <SelectTrigger className="w-[140px] h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">New</SelectItem>
                          <SelectItem value="contacted">Contacted</SelectItem>
                          <SelectItem value="interested">Interested</SelectItem>
                          <SelectItem value="closed">Closed</SelectItem>
                          <SelectItem value="archived">Archived</SelectItem>
                        </SelectContent>
                      </Select>

                      <Select value={fav.priority} onValueChange={(val) => updateFavoritePriority(fav.id, val)}>
                        <SelectTrigger className="w-[120px] h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="urgent">Urgent</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="low">Low</SelectItem>
                        </SelectContent>
                      </Select>

                      {fav.last_contacted && (
                        <Badge variant="outline" className="text-xs">
                          Last: {new Date(fav.last_contacted).toLocaleDateString('id-ID')}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
};
