import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Activity, AlertCircle, CheckCircle, Settings } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";

interface QuotaData {
  used: number;
  limit: number;
  resetDate: string;
}

export const APIQuotaTracker = () => {
  const [quota, setQuota] = useState<QuotaData>({
    used: 0,
    limit: 100,
    resetDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1).toISOString(),
  });
  const [maxResults, setMaxResults] = useState(20);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    loadQuotaData();
  }, []);

  const loadQuotaData = () => {
    const savedQuota = localStorage.getItem('api_quota');
    const savedMaxResults = localStorage.getItem('max_results');
    
    if (savedQuota) {
      setQuota(JSON.parse(savedQuota));
    }
    if (savedMaxResults) {
      setMaxResults(parseInt(savedMaxResults));
    }
  };

  const saveQuotaData = (newQuota: QuotaData) => {
    localStorage.setItem('api_quota', JSON.stringify(newQuota));
    setQuota(newQuota);
  };

  const incrementUsage = () => {
    const newQuota = {
      ...quota,
      used: quota.used + 1,
    };
    saveQuotaData(newQuota);
  };

  const resetQuota = () => {
    const newQuota = {
      ...quota,
      used: 0,
      resetDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1).toISOString(),
    };
    saveQuotaData(newQuota);
  };

  const updateLimit = (newLimit: number) => {
    const newQuota = {
      ...quota,
      limit: newLimit,
    };
    saveQuotaData(newQuota);
  };

  const updateMaxResults = (value: number) => {
    setMaxResults(value);
    localStorage.setItem('max_results', value.toString());
  };

  const percentageUsed = (quota.used / quota.limit) * 100;
  const remaining = quota.limit - quota.used;
  const resetDate = new Date(quota.resetDate).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  // Auto increment on search (this would be called from Index page)
  useEffect(() => {
    const handleSearchComplete = () => {
      incrementUsage();
    };
    
    window.addEventListener('search-completed', handleSearchComplete);
    return () => window.removeEventListener('search-completed', handleSearchComplete);
  }, [quota]);

  return (
    <Card className="p-5 shadow-md border-border/50 bg-gradient-to-br from-card to-card/50">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-primary/10">
            <Activity className="h-4 w-4 text-primary" />
          </div>
          <h3 className="font-semibold text-foreground">API Quota</h3>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="sm" className="hover:bg-primary/10 h-8 w-8 p-0">
              <Settings className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>API Settings</DialogTitle>
              <DialogDescription>
                Kelola quota dan limit pencarian API
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Monthly Limit</Label>
                <Input
                  type="number"
                  value={quota.limit}
                  onChange={(e) => updateLimit(parseInt(e.target.value) || 100)}
                  className="mt-2"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  SerpAPI free tier: 100 searches/bulan
                </p>
              </div>
              <div>
                <Label>Max Results per Search</Label>
                <Input
                  type="number"
                  value={maxResults}
                  onChange={(e) => updateMaxResults(parseInt(e.target.value) || 20)}
                  className="mt-2"
                  min="1"
                  max="100"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Batasi jumlah hasil untuk menghemat quota
                </p>
              </div>
              <Button onClick={resetQuota} variant="outline" className="w-full">
                Reset Quota Counter
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Progress Bar with Better Styling */}
      <div className="space-y-3 mb-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground font-medium">Used</span>
          <span className="font-semibold text-foreground">
            {quota.used} <span className="text-muted-foreground">/ {quota.limit}</span>
          </span>
        </div>
        <Progress value={percentageUsed} className="h-2.5" />
      </div>

      {/* Status Badge with Better Colors */}
      <div className="mb-4">
        {remaining > 20 ? (
          <Badge variant="default" className="bg-emerald-500/90 hover:bg-emerald-500 border-0 shadow-sm">
            <CheckCircle className="h-3 w-3 mr-1" />
            {remaining} searches tersisa
          </Badge>
        ) : remaining > 0 ? (
          <Badge variant="secondary" className="bg-amber-500/90 hover:bg-amber-500 text-white border-0 shadow-sm">
            <AlertCircle className="h-3 w-3 mr-1" />
            {remaining} searches tersisa
          </Badge>
        ) : (
          <Badge variant="destructive" className="shadow-sm">
            <AlertCircle className="h-3 w-3 mr-1" />
            Quota habis
          </Badge>
        )}
      </div>

      {/* Reset Info with Better Typography */}
      <div className="text-xs text-muted-foreground px-3 py-2 rounded-md bg-muted/30">
        Reset: <span className="font-medium text-foreground">{resetDate}</span>
      </div>

      {/* Quick Stats with Enhanced Design */}
      <div className="mt-4 pt-4 border-t border-border/50 grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">Per Search</p>
          <p className="text-lg font-semibold text-foreground">{maxResults}</p>
          <p className="text-xs text-muted-foreground">results</p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">Efficiency</p>
          <p className="text-lg font-semibold text-foreground">
            {quota.used > 0 ? Math.round((quota.used / quota.limit) * 100) : 0}%
          </p>
          <p className="text-xs text-muted-foreground">used</p>
        </div>
      </div>
    </Card>
  );
};
