import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrapingResult } from "@/pages/Index";
import { MapPin, Phone, Globe, Star, MessageSquare, Copy, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ResultDetailModalProps {
  result: ScrapingResult | null;
  open: boolean;
  onClose: () => void;
}

export const ResultDetailModal = ({ result, open, onClose }: ResultDetailModalProps) => {
  const { toast } = useToast();

  if (!result) return null;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Berhasil Disalin",
      description: `${label} telah disalin ke clipboard`,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{result.name}</DialogTitle>
          <DialogDescription>
            Detail informasi lengkap tentang bisnis ini
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Rating & Reviews */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
              <span className="text-2xl font-bold">{result.rating}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <MessageSquare className="h-4 w-4" />
              <span>{result.reviewCount.toLocaleString()} ulasan</span>
            </div>
            <div className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
              {result.category}
            </div>
          </div>

          {/* Address */}
          <div className="space-y-2">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-sm text-muted-foreground">Alamat</p>
                <p className="text-base">{result.address}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="mt-2 h-8"
                  onClick={() => copyToClipboard(result.address, "Alamat")}
                >
                  <Copy className="h-3 w-3 mr-2" />
                  Salin Alamat
                </Button>
              </div>
            </div>
          </div>

          {/* Phone */}
          {result.phone && result.phone !== "-" && (
            <div className="space-y-2">
              <div className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-primary mt-0.5" />
                <div className="flex-1">
                  <p className="font-medium text-sm text-muted-foreground">Telepon</p>
                  <p className="text-base">{result.phone}</p>
                  <div className="flex gap-2 mt-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8"
                      onClick={() => copyToClipboard(result.phone, "Nomor telepon")}
                    >
                      <Copy className="h-3 w-3 mr-2" />
                      Salin
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8"
                      asChild
                    >
                      <a href={`tel:${result.phone}`}>
                        <Phone className="h-3 w-3 mr-2" />
                        Telepon
                      </a>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8"
                      asChild
                    >
                      <a
                        href={`https://wa.me/${result.phone.replace(/\D/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <MessageSquare className="h-3 w-3 mr-2" />
                        WhatsApp
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Website */}
          {result.website && result.website !== "-" && (
            <div className="space-y-2">
              <div className="flex items-start gap-3">
                <Globe className="h-5 w-5 text-primary mt-0.5" />
                <div className="flex-1">
                  <p className="font-medium text-sm text-muted-foreground">Website</p>
                  <p className="text-base break-all">{result.website}</p>
                  <div className="flex gap-2 mt-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8"
                      onClick={() => copyToClipboard(result.website, "Website")}
                    >
                      <Copy className="h-3 w-3 mr-2" />
                      Salin
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8"
                      asChild
                    >
                      <a
                        href={result.website.startsWith('http') ? result.website : `https://${result.website}`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="h-3 w-3 mr-2" />
                        Buka Website
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
