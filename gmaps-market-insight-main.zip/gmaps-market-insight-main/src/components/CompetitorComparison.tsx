import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrapingResult } from "@/pages/Index";
import { GitCompare, Star, MessageSquare, Globe, Phone, Trophy } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface CompetitorComparisonProps {
  results: ScrapingResult[];
}

export const CompetitorComparison = ({ results }: CompetitorComparisonProps) => {
  const [selectedResults, setSelectedResults] = useState<string[]>([]);
  const [open, setOpen] = useState(false);

  const toggleSelection = (id: string) => {
    setSelectedResults(prev => {
      if (prev.includes(id)) {
        return prev.filter(resultId => resultId !== id);
      }
      if (prev.length >= 5) {
        return prev;
      }
      return [...prev, id];
    });
  };

  const compareResults = results.filter(r => selectedResults.includes(r.id));

  // Find best performers
  const bestRating = compareResults.length > 0 
    ? Math.max(...compareResults.map(r => r.rating)) 
    : 0;
  const bestReviews = compareResults.length > 0 
    ? Math.max(...compareResults.map(r => r.reviewCount)) 
    : 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <GitCompare className="h-4 w-4" />
          Bandingkan ({selectedResults.length}/5)
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Competitor Comparison</DialogTitle>
          <DialogDescription>
            Bandingkan hingga 5 bisnis sekaligus untuk melihat performa terbaik
          </DialogDescription>
        </DialogHeader>

        {compareResults.length === 0 ? (
          <div className="py-8">
            <p className="text-center text-muted-foreground mb-4">
              Pilih hingga 5 bisnis untuk dibandingkan
            </p>
            <ScrollArea className="h-[400px]">
              <div className="space-y-2">
                {results.slice(0, 20).map((result) => (
                  <div
                    key={result.id}
                    className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/50 cursor-pointer"
                    onClick={() => toggleSelection(result.id)}
                  >
                    <Checkbox
                      checked={selectedResults.includes(result.id)}
                      onCheckedChange={() => toggleSelection(result.id)}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{result.name}</p>
                      <div className="flex items-center gap-4 mt-1">
                        <span className="text-sm flex items-center gap-1">
                          <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                          {result.rating}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {result.reviewCount} ulasan
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
        ) : (
          <ScrollArea className="h-[600px]">
            <div className="space-y-6">
              {/* Comparison Table */}
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3 font-semibold">Metrik</th>
                      {compareResults.map((result) => (
                        <th key={result.id} className="text-left p-3 font-semibold min-w-[200px]">
                          <div className="flex items-center gap-2">
                            {result.name}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleSelection(result.id)}
                              className="h-6 w-6 p-0"
                            >
                              ×
                            </Button>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {/* Rating */}
                    <tr className="border-b hover:bg-muted/50">
                      <td className="p-3 font-medium">
                        <div className="flex items-center gap-2">
                          <Star className="h-4 w-4 text-yellow-400" />
                          Rating
                        </div>
                      </td>
                      {compareResults.map((result) => (
                        <td key={result.id} className="p-3">
                          <div className="flex items-center gap-2">
                            <span className="text-lg font-bold">{result.rating}</span>
                            {result.rating === bestRating && (
                              <Trophy className="h-4 w-4 text-yellow-500" />
                            )}
                          </div>
                        </td>
                      ))}
                    </tr>

                    {/* Reviews */}
                    <tr className="border-b hover:bg-muted/50">
                      <td className="p-3 font-medium">
                        <div className="flex items-center gap-2">
                          <MessageSquare className="h-4 w-4 text-primary" />
                          Jumlah Ulasan
                        </div>
                      </td>
                      {compareResults.map((result) => (
                        <td key={result.id} className="p-3">
                          <div className="flex items-center gap-2">
                            <span className="text-lg font-bold">
                              {result.reviewCount.toLocaleString()}
                            </span>
                            {result.reviewCount === bestReviews && (
                              <Trophy className="h-4 w-4 text-yellow-500" />
                            )}
                          </div>
                        </td>
                      ))}
                    </tr>

                    {/* Category */}
                    <tr className="border-b hover:bg-muted/50">
                      <td className="p-3 font-medium">Kategori</td>
                      {compareResults.map((result) => (
                        <td key={result.id} className="p-3">
                          <Badge variant="secondary">{result.category}</Badge>
                        </td>
                      ))}
                    </tr>

                    {/* Website */}
                    <tr className="border-b hover:bg-muted/50">
                      <td className="p-3 font-medium">
                        <div className="flex items-center gap-2">
                          <Globe className="h-4 w-4 text-primary" />
                          Website
                        </div>
                      </td>
                      {compareResults.map((result) => (
                        <td key={result.id} className="p-3">
                          {result.website && result.website !== "-" ? (
                            <Badge variant="default" className="bg-green-500">Ada</Badge>
                          ) : (
                            <Badge variant="secondary">Tidak Ada</Badge>
                          )}
                        </td>
                      ))}
                    </tr>

                    {/* Phone */}
                    <tr className="border-b hover:bg-muted/50">
                      <td className="p-3 font-medium">
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-primary" />
                          Telepon
                        </div>
                      </td>
                      {compareResults.map((result) => (
                        <td key={result.id} className="p-3">
                          {result.phone && result.phone !== "-" ? (
                            <span className="text-sm">{result.phone}</span>
                          ) : (
                            <Badge variant="secondary">Tidak Ada</Badge>
                          )}
                        </td>
                      ))}
                    </tr>

                    {/* Address */}
                    <tr className="hover:bg-muted/50">
                      <td className="p-3 font-medium">Alamat</td>
                      {compareResults.map((result) => (
                        <td key={result.id} className="p-3">
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {result.address}
                          </p>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Summary */}
              <div className="p-4 bg-muted rounded-lg">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-500" />
                  Best Performers
                </h4>
                <div className="space-y-2 text-sm">
                  <p>
                    <strong>Highest Rating:</strong>{" "}
                    {compareResults.find(r => r.rating === bestRating)?.name} ({bestRating})
                  </p>
                  <p>
                    <strong>Most Reviews:</strong>{" "}
                    {compareResults.find(r => r.reviewCount === bestReviews)?.name} ({bestReviews.toLocaleString()})
                  </p>
                </div>
              </div>
            </div>
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
};
