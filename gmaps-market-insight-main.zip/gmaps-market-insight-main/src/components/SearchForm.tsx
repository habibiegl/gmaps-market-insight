import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search, Loader2, Key, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SearchFormProps {
  onSearch: (data: {
    keyword: string;
    province: string;
    city: string;
    district: string;
    apiKey: string;
  }) => void;
  isLoading: boolean;
}

export const SearchForm = ({ onSearch, isLoading }: SearchFormProps) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    keyword: "",
    province: "",
    city: "",
    district: "",
    apiKey: "",
  });

  // Load API key from localStorage on mount
  useEffect(() => {
    const savedApiKey = localStorage.getItem("gmaps_scraper_api_key");
    if (savedApiKey) {
      setFormData((prev) => ({ ...prev, apiKey: savedApiKey }));
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.apiKey.trim()) {
      toast({
        title: "API Key Diperlukan",
        description: "Mohon masukkan API Key terlebih dahulu",
        variant: "destructive",
      });
      return;
    }

    if (!formData.keyword || !formData.province || !formData.city) {
      toast({
        title: "Form Tidak Lengkap",
        description: "Mohon isi kata kunci, provinsi, dan kota",
        variant: "destructive",
      });
      return;
    }

    // Save API key to localStorage
    localStorage.setItem("gmaps_scraper_api_key", formData.apiKey);

    onSearch(formData);
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* API Key Section with Visual Emphasis */}
      <div className="space-y-3 p-4 rounded-lg bg-gradient-to-br from-primary/5 to-accent/5 border border-primary/10">
        <Label htmlFor="apiKey" className="text-sm font-semibold flex items-center gap-2 text-foreground">
          <Key className="h-4 w-4 text-primary" />
          API Key
        </Label>
        <Input
          id="apiKey"
          type="password"
          placeholder="Masukkan API Key SerpAPI"
          value={formData.apiKey}
          onChange={(e) => handleChange("apiKey", e.target.value)}
          disabled={isLoading}
          className="font-mono text-sm border-primary/20 focus-visible:ring-primary/30 bg-background/50"
        />
        <p className="text-xs text-muted-foreground flex items-center gap-1">
          <CheckCircle className="h-3 w-3" />
          API Key akan disimpan di browser Anda
        </p>
      </div>

      {/* Divider */}
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-border/50" />
        </div>
        <div className="relative flex justify-center text-xs">
          <span className="bg-card px-2 text-muted-foreground">Parameter Lokasi</span>
        </div>
      </div>

      {/* Search Parameters */}
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="keyword" className="text-sm font-medium text-foreground">
            Kata Kunci Pencarian
          </Label>
          <Input
            id="keyword"
            placeholder="Contoh: Grosir Keripik"
            value={formData.keyword}
            onChange={(e) => handleChange("keyword", e.target.value)}
            disabled={isLoading}
            className="border-border/50 focus-visible:ring-primary/30 hover:border-primary/30 transition-colors"
          />
        </div>

        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <Label htmlFor="province" className="text-sm font-medium text-foreground">
              Provinsi
            </Label>
            <Input
              id="province"
              placeholder="Contoh: DKI Jakarta"
              value={formData.province}
              onChange={(e) => handleChange("province", e.target.value)}
              disabled={isLoading}
              className="border-border/50 focus-visible:ring-primary/30 hover:border-primary/30 transition-colors"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="city" className="text-sm font-medium text-foreground">
              Kota/Kabupaten
            </Label>
            <Input
              id="city"
              placeholder="Contoh: Jakarta Selatan"
              value={formData.city}
              onChange={(e) => handleChange("city", e.target.value)}
              disabled={isLoading}
              className="border-border/50 focus-visible:ring-primary/30 hover:border-primary/30 transition-colors"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="district" className="text-sm font-medium text-foreground">
            Kecamatan <span className="text-xs text-muted-foreground font-normal">(Opsional)</span>
          </Label>
          <Input
            id="district"
            placeholder="Contoh: Pasar Minggu"
            value={formData.district}
            onChange={(e) => handleChange("district", e.target.value)}
            disabled={isLoading}
            className="border-border/50 focus-visible:ring-primary/30 hover:border-primary/30 transition-colors"
          />
        </div>
      </div>

      {/* Submit Button with Enhanced Styling */}
      <Button
        type="submit"
        disabled={isLoading}
        size="lg"
        className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-all shadow-md hover:shadow-lg hover:scale-[1.02] active:scale-[0.98]"
      >
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Mencari Data...
          </>
        ) : (
          <>
            <Search className="mr-2 h-4 w-4" />
            Mulai Scraping
          </>
        )}
      </Button>
    </form>
  );
};
