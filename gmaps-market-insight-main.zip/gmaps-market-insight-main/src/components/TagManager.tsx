import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tag, Plus, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface TagManagerProps {
  placeId: string;
  existingTags?: string[];
  onTagsUpdated?: () => void;
}

interface TagType {
  id: string;
  name: string;
  color: string;
}

export const TagManager = ({ placeId, existingTags = [], onTagsUpdated }: TagManagerProps) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [allTags, setAllTags] = useState<TagType[]>([]);
  const [resultTags, setResultTags] = useState<string[]>(existingTags);
  const [newTagName, setNewTagName] = useState("");

  useEffect(() => {
    if (open) {
      loadTags();
      loadResultTags();
    }
  }, [open, placeId]);

  const loadTags = async () => {
    try {
      const { data, error } = await supabase
        .from('tags')
        .select('*')
        .order('name');

      if (error) throw error;
      setAllTags(data || []);
    } catch (error) {
      console.error('Error loading tags:', error);
    }
  };

  const loadResultTags = async () => {
    try {
      const { data, error } = await supabase
        .from('result_tags')
        .select('tag_id, tags(name)')
        .eq('place_id', placeId);

      if (error) throw error;
      
      const tagNames = data?.map((rt: any) => rt.tags.name) || [];
      setResultTags(tagNames);
    } catch (error) {
      console.error('Error loading result tags:', error);
    }
  };

  const createTag = async () => {
    if (!newTagName.trim()) return;

    try {
      const { error } = await supabase
        .from('tags')
        .insert([{ name: newTagName.trim(), color: '#10b981' }]);

      if (error) throw error;

      toast({
        title: "Tag Created",
        description: `Tag "${newTagName}" berhasil dibuat`,
      });

      setNewTagName("");
      loadTags();
    } catch (error: any) {
      if (error.code === '23505') {
        toast({
          title: "Tag Already Exists",
          description: "Tag dengan nama ini sudah ada",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Gagal membuat tag",
          variant: "destructive",
        });
      }
    }
  };

  const addTagToResult = async (tagId: string, tagName: string) => {
    try {
      const { error } = await supabase
        .from('result_tags')
        .insert([{ place_id: placeId, tag_id: tagId }]);

      if (error) throw error;

      setResultTags([...resultTags, tagName]);
      toast({
        title: "Tag Added",
        description: `Tag "${tagName}" ditambahkan`,
      });
      onTagsUpdated?.();
    } catch (error: any) {
      if (error.code === '23505') {
        toast({
          title: "Already Tagged",
          description: "Tag ini sudah ada",
          variant: "destructive",
        });
      }
    }
  };

  const removeTagFromResult = async (tagName: string) => {
    try {
      const tag = allTags.find(t => t.name === tagName);
      if (!tag) return;

      const { error } = await supabase
        .from('result_tags')
        .delete()
        .eq('place_id', placeId)
        .eq('tag_id', tag.id);

      if (error) throw error;

      setResultTags(resultTags.filter(t => t !== tagName));
      toast({
        title: "Tag Removed",
        description: `Tag "${tagName}" dihapus`,
      });
      onTagsUpdated?.();
    } catch (error) {
      console.error('Error removing tag:', error);
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2">
          <Tag className="h-3 w-3" />
          {resultTags.length > 0 ? `${resultTags.length} tags` : 'Add Tags'}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-2">Current Tags</h4>
            <div className="flex flex-wrap gap-2 mb-3">
              {resultTags.length > 0 ? (
                resultTags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="gap-1">
                    {tag}
                    <button
                      onClick={() => removeTagFromResult(tag)}
                      className="ml-1 hover:bg-destructive hover:text-destructive-foreground rounded-full"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">Belum ada tags</p>
              )}
            </div>
          </div>

          <div>
            <h4 className="font-medium mb-2">Add Tag</h4>
            <ScrollArea className="h-32 border rounded p-2">
              <div className="space-y-1">
                {allTags.filter(t => !resultTags.includes(t.name)).map((tag) => (
                  <button
                    key={tag.id}
                    onClick={() => addTagToResult(tag.id, tag.name)}
                    className="w-full text-left px-2 py-1 text-sm hover:bg-muted rounded"
                  >
                    <Badge variant="outline" style={{ borderColor: tag.color }}>
                      {tag.name}
                    </Badge>
                  </button>
                ))}
              </div>
            </ScrollArea>
          </div>

          <div>
            <h4 className="font-medium mb-2">Create New Tag</h4>
            <div className="flex gap-2">
              <Input
                placeholder="Tag name..."
                value={newTagName}
                onChange={(e) => setNewTagName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && createTag()}
              />
              <Button onClick={createTag} size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};
