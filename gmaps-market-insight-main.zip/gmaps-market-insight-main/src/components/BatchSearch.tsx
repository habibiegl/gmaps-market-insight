import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Layers, Play, Pause, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface BatchSearchProps {
  onSearch: (searchData: {
    keyword: string;
    province: string;
    city: string;
    district: string;
    apiKey: string;
  }) => Promise<void>;
  lastSearchData: {
    province: string;
    city: string;
    district: string;
    apiKey: string;
  } | null;
}

export const BatchSearch = ({ onSearch, lastSearchData }: BatchSearchProps) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [keywords, setKeywords] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentKeyword, setCurrentKeyword] = useState("");

  const handleBatchSearch = async () => {
    if (!lastSearchData) {
      toast({
        title: "Data Pencarian Tidak Ada",
        description: "Lakukan pencarian pertama untuk menggunakan lokasi dan API key yang sama",
        variant: "destructive",
      });
      return;
    }

    const keywordList = keywords
      .split("\n")
      .map(k => k.trim())
      .filter(k => k.length > 0);

    if (keywordList.length === 0) {
      toast({
        title: "Tidak Ada Keyword",
        description: "Masukkan minimal 1 keyword",
        variant: "destructive",
      });
      return;
    }

    if (keywordList.length > 10) {
      toast({
        title: "Terlalu Banyak",
        description: "Maximum 10 keywords per batch",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    let successCount = 0;
    let failCount = 0;
    
    for (let i = 0; i < keywordList.length; i++) {
      const keyword = keywordList[i];
      setCurrentKeyword(keyword);
      setProgress(((i) / keywordList.length) * 100);

      try {
        // Use the actual search function with last search location/API key
        await onSearch({
          keyword: keyword,
          province: lastSearchData.province,
          city: lastSearchData.city,
          district: lastSearchData.district,
          apiKey: lastSearchData.apiKey,
        });
        
        successCount++;
        
        toast({
          title: "Search Completed",
          description: `"${keyword}" berhasil di-scrape`,
        });
      } catch (error: any) {
        failCount++;
        console.error(`Error scraping "${keyword}":`, error);
        toast({
          title: "Search Failed",
          description: `Gagal scraping "${keyword}": ${error.message || 'Unknown error'}`,
          variant: "destructive",
        });
      }

      // Update progress after completion
      setProgress(((i + 1) / keywordList.length) * 100);

      // Small delay between searches to avoid rate limiting
      if (i < keywordList.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 2000)); // 2 second delay between searches
      }
    }

    setIsProcessing(false);
    setProgress(0);
    setCurrentKeyword("");
    
    toast({
      title: "Batch Search Complete",
      description: `${successCount} berhasil, ${failCount} gagal dari ${keywordList.length} keywords`,
      duration: 5000,
    });
    
    // Close dialog after completion
    if (successCount > 0) {
      setTimeout(() => setOpen(false), 2000);
    }
  };

  const keywordCount = keywords.split("\n").filter(k => k.trim().length > 0).length;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Layers className="h-4 w-4" />
          Batch Search
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Batch Search</DialogTitle>
          <DialogDescription>
            Scrape multiple keywords sekaligus untuk riset yang lebih efisien
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label>Keywords (satu per baris)</Label>
            <Textarea
              placeholder="contoh:&#10;Grosir Keripik&#10;Toko Snack&#10;Distributor Makanan"
              value={keywords}
              onChange={(e) => setKeywords(e.target.value)}
              className="mt-2 h-[200px] font-mono text-sm"
              disabled={isProcessing}
            />
            <div className="flex items-center justify-between mt-2">
              <p className="text-xs text-muted-foreground">
                Maximum 10 keywords per batch
              </p>
              <Badge variant={keywordCount > 10 ? "destructive" : "secondary"}>
                {keywordCount} keywords
              </Badge>
            </div>
          </div>

          {isProcessing && (
            <div className="space-y-3 p-4 bg-muted rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Processing...</span>
                <span className="text-sm text-muted-foreground">
                  {Math.round(progress)}%
                </span>
              </div>
              <Progress value={progress} />
              <p className="text-sm text-muted-foreground">
                Current: <strong>{currentKeyword}</strong>
              </p>
            </div>
          )}

          <div className="flex items-start gap-2 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
            <AlertCircle className="h-4 w-4 text-yellow-600 mt-0.5" />
            <div className="text-sm text-yellow-700 dark:text-yellow-500">
              <p className="font-medium">Perhatian</p>
              <p className="text-xs mt-1">
                Batch search akan menggunakan {keywordCount} quota API. Pastikan quota Anda mencukupi.
                <br />
                Lokasi: <strong>{lastSearchData?.city || '-'}, {lastSearchData?.province || '-'}</strong>
              </p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={handleBatchSearch}
              disabled={isProcessing || keywordCount === 0 || keywordCount > 10}
              className="flex-1"
            >
              {isProcessing ? (
                <>
                  <Pause className="h-4 w-4 mr-2" />
                  Processing...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Start Batch Search
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
