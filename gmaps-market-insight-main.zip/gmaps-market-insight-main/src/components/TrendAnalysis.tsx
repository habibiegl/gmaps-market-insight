import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, BarChart3 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

interface TrendData {
  keyword: string;
  count: number;
  avgRating: number;
  totalResults: number;
  trend: 'up' | 'down' | 'stable';
}

export const TrendAnalysis = () => {
  const [trendData, setTrendData] = useState<TrendData[]>([]);
  const [categoryHeatmap, setCategoryHeatmap] = useState<{ category: string; count: number; }[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadTrendData();
  }, []);

  const loadTrendData = async () => {
    try {
      // Get search history
      const { data: history, error } = await supabase
        .from('search_history')
        .select('keyword, results_count, created_at')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;

      // Analyze keyword trends
      const keywordMap = new Map<string, { count: number; totalResults: number }>();
      
      history?.forEach(item => {
        const existing = keywordMap.get(item.keyword) || { count: 0, totalResults: 0 };
        keywordMap.set(item.keyword, {
          count: existing.count + 1,
          totalResults: existing.totalResults + (item.results_count || 0),
        });
      });

      const trends: TrendData[] = Array.from(keywordMap.entries())
        .map(([keyword, data]) => ({
          keyword,
          count: data.count,
          avgRating: 4.2, // Placeholder
          totalResults: data.totalResults,
          trend: data.count > 2 ? 'up' : 'stable' as 'up' | 'down' | 'stable',
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      setTrendData(trends);

      // Get category heatmap
      const { data: results } = await supabase
        .from('scraping_results')
        .select('category')
        .limit(1000);

      if (results) {
        const categoryMap = new Map<string, number>();
        results.forEach(r => {
          if (r.category) {
            categoryMap.set(r.category, (categoryMap.get(r.category) || 0) + 1);
          }
        });

        const heatmap = Array.from(categoryMap.entries())
          .map(([category, count]) => ({ category, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 15);

        setCategoryHeatmap(heatmap);
      }

      setIsLoading(false);
    } catch (error) {
      console.error('Error loading trend data:', error);
      setIsLoading(false);
    }
  };

  const getColorByCount = (count: number, max: number) => {
    const intensity = count / max;
    if (intensity > 0.7) return '#ef4444'; // red
    if (intensity > 0.4) return '#f59e0b'; // orange
    return '#3b82f6'; // blue
  };

  const maxCount = Math.max(...categoryHeatmap.map(c => c.count), 1);

  return (
    <div className="space-y-6">
      {/* Keyword Trends */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">Keyword Trends</h3>
        </div>

        {isLoading ? (
          <p className="text-muted-foreground text-center py-8">Loading trends...</p>
        ) : trendData.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">
            Belum ada data trend. Lakukan beberapa pencarian terlebih dahulu.
          </p>
        ) : (
          <div className="space-y-3">
            {trendData.map((trend, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold text-sm">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium">{trend.keyword}</p>
                    <p className="text-sm text-muted-foreground">
                      {trend.count} pencarian · {trend.totalResults} hasil
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {trend.trend === 'up' ? (
                    <TrendingUp className="h-5 w-5 text-green-500" />
                  ) : trend.trend === 'down' ? (
                    <TrendingDown className="h-5 w-5 text-red-500" />
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Category Heatmap */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">Category Heatmap</h3>
        </div>

        {isLoading ? (
          <p className="text-muted-foreground text-center py-8">Loading heatmap...</p>
        ) : categoryHeatmap.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">
            Belum ada data kategori
          </p>
        ) : (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={categoryHeatmap}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="category"
                angle={-45}
                textAnchor="end"
                height={100}
                fontSize={12}
              />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                {categoryHeatmap.map((entry, index) => (
                  <Cell key={index} fill={getColorByCount(entry.count, maxCount)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </Card>

      {/* Refresh Button */}
      <Button onClick={loadTrendData} variant="outline" className="w-full">
        Refresh Trend Data
      </Button>
    </div>
  );
};
