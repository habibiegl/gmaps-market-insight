import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Download, Loader2, Star, MapPin, Phone, Globe, ArrowUpDown, Eye, ChevronLeft, ChevronRight } from "lucide-react";
import { ScrapingResult } from "@/pages/Index";
import * as XLSX from "xlsx";
import { useToast } from "@/hooks/use-toast";
import { ResultDetailModal } from "./ResultDetailModal";
import { TagManager } from "./TagManager";
import { BusinessNotes } from "./BusinessNotes";

interface ResultsTableProps {
  results: ScrapingResult[];
  isLoading: boolean;
  selectedResults?: string[];
  onSelectionChange?: (selected: string[]) => void;
}

type SortField = "name" | "rating" | "reviewCount" | "category";
type SortOrder = "asc" | "desc";

export const ResultsTable = ({ results, isLoading, selectedResults = [], onSelectionChange }: ResultsTableProps) => {
  const { toast } = useToast();
  const [sortField, setSortField] = useState<SortField>("rating");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedResult, setSelectedResult] = useState<ScrapingResult | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  
  const itemsPerPage = 10;

  const toggleSelection = (id: string) => {
    if (!onSelectionChange) return;
    
    if (selectedResults.includes(id)) {
      onSelectionChange(selectedResults.filter(r => r !== id));
    } else {
      onSelectionChange([...selectedResults, id]);
    }
  };

  const toggleSelectAll = () => {
    if (!onSelectionChange) return;
    
    if (selectedResults.length === paginatedResults.length) {
      onSelectionChange([]);
    } else {
      onSelectionChange(paginatedResults.map(r => r.id));
    }
  };

  // Sorting logic
  const sortedResults = [...results].sort((a, b) => {
    const multiplier = sortOrder === "asc" ? 1 : -1;
    
    switch (sortField) {
      case "name":
        return multiplier * a.name.localeCompare(b.name);
      case "rating":
        return multiplier * (a.rating - b.rating);
      case "reviewCount":
        return multiplier * (a.reviewCount - b.reviewCount);
      case "category":
        return multiplier * a.category.localeCompare(b.category);
      default:
        return 0;
    }
  });

  // Pagination logic
  const totalPages = Math.ceil(sortedResults.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedResults = sortedResults.slice(startIndex, endIndex);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("desc");
    }
    setCurrentPage(1);
  };

  const handleExport = () => {
    if (results.length === 0) {
      toast({
        title: "Tidak Ada Data",
        description: "Lakukan pencarian terlebih dahulu",
        variant: "destructive",
      });
      return;
    }

    const worksheet = XLSX.utils.json_to_sheet(
      results.map((result) => ({
        Nama: result.name,
        Alamat: result.address,
        "Situs Web": result.website,
        Telepon: result.phone,
        "Jumlah Ulasan": result.reviewCount,
        "Rating Rata-Rata": result.rating,
        Kategori: result.category,
      }))
    );

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Hasil Scraping");
    XLSX.writeFile(workbook, `google-maps-scraping-${Date.now()}.xlsx`);

    toast({
      title: "Berhasil Export",
      description: `${results.length} data berhasil diexport ke Excel`,
    });
  };

  const handleViewDetail = (result: ScrapingResult) => {
    setSelectedResult(result);
    setShowDetailModal(true);
  };

  if (isLoading) {
    return (
      <Card className="p-16 text-center shadow-md bg-gradient-to-br from-card to-card/50 border-border/50">
        <Loader2 className="h-12 w-12 animate-spin mx-auto text-primary mb-4" />
        <p className="text-muted-foreground font-medium">Mengumpulkan data dari Google Maps...</p>
        <p className="text-xs text-muted-foreground mt-2">Proses ini mungkin memakan waktu beberapa saat</p>
      </Card>
    );
  }

  if (results.length === 0) {
    return (
      <Card className="p-16 text-center bg-gradient-to-br from-card to-card/50 border-border/50 shadow-md">
        <div className="max-w-md mx-auto space-y-4">
          <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto">
            <MapPin className="h-12 w-12 text-primary" />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-bold text-foreground">Belum Ada Hasil</h3>
            <p className="text-muted-foreground leading-relaxed">
              Masukkan parameter pencarian dan klik <span className="font-semibold text-foreground">"Mulai Scraping"</span> untuk memulai
            </p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <>
      <Card className="shadow-lg overflow-hidden border-border/50">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-border/50 bg-gradient-to-r from-primary/8 to-accent/8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2 text-foreground">
                <div className="p-1.5 rounded-lg bg-primary/10">
                  <MapPin className="h-4 w-4 text-primary" />
                </div>
                Hasil Pencarian
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                Menampilkan <span className="font-medium text-foreground">{startIndex + 1}-{Math.min(endIndex, results.length)}</span> dari <span className="font-medium text-foreground">{results.length}</span> hasil
              </p>
            </div>
            <Button
              onClick={handleExport}
              className="bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-md hover:shadow-lg transition-all w-full sm:w-auto"
            >
              <Download className="mr-2 h-4 w-4" />
              Export ke Excel
            </Button>
          </div>
        </div>

        {/* Desktop Table View - Hidden on mobile */}
        <div className="hidden md:block overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-12">
                  <Checkbox
                    checked={selectedResults.length === paginatedResults.length && paginatedResults.length > 0}
                    onCheckedChange={toggleSelectAll}
                  />
                </TableHead>
                <TableHead className="font-semibold">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSort("name")}
                    className="hover:bg-transparent"
                  >
                    Nama
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="font-semibold">Alamat</TableHead>
                <TableHead className="font-semibold">Kontak</TableHead>
                <TableHead className="font-semibold text-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSort("reviewCount")}
                    className="hover:bg-transparent"
                  >
                    Ulasan
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="font-semibold text-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSort("rating")}
                    className="hover:bg-transparent"
                  >
                    Rating
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="font-semibold">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSort("category")}
                    className="hover:bg-transparent"
                  >
                    Kategori
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="font-semibold text-center">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedResults.map((result) => (
                <TableRow
                  key={result.id}
                  className="hover:bg-muted/30 transition-colors"
                >
                  <TableCell>
                    <Checkbox
                      checked={selectedResults.includes(result.id)}
                      onCheckedChange={() => toggleSelection(result.id)}
                    />
                  </TableCell>
                  <TableCell className="font-medium">{result.name}</TableCell>
                  <TableCell className="text-sm text-muted-foreground max-w-xs truncate">
                    {result.address}
                  </TableCell>
                  <TableCell className="text-sm">
                    <div className="space-y-1">
                      {result.website && result.website !== "-" && (
                        <a
                          href={result.website.startsWith('http') ? result.website : `https://${result.website}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 text-primary hover:underline"
                        >
                          <Globe className="h-3 w-3" />
                          <span className="truncate max-w-[150px]">Website</span>
                        </a>
                      )}
                      {result.phone && result.phone !== "-" && (
                        <a
                          href={`tel:${result.phone}`}
                          className="flex items-center gap-1 hover:text-primary"
                        >
                          <Phone className="h-3 w-3" />
                          <span className="truncate">{result.phone}</span>
                        </a>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-center font-medium">
                    {result.reviewCount.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-semibold">{result.rating}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                      {result.category}
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewDetail(result)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <TagManager placeId={result.id} />
                      <BusinessNotes placeId={result.id} businessName={result.name} />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Mobile Card View - Hidden on desktop */}
        <div className="md:hidden p-4 space-y-4">
          {paginatedResults.map((result, index) => (
            <Card
              key={index}
              className="p-4 space-y-3 hover:shadow-md transition-shadow border-border/50"
              onClick={() => handleViewDetail(result)}
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{result.name}</h3>
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary mt-1">
                    {result.category}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleViewDetail(result);
                  }}
                >
                  <Eye className="h-4 w-4" />
                </Button>
              </div>

              {/* Rating & Reviews */}
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-bold">{result.rating}</span>
                </div>
                <span className="text-sm text-muted-foreground">
                  {result.reviewCount.toLocaleString()} ulasan
                </span>
              </div>

              {/* Address */}
              <div className="flex items-start gap-2 text-sm">
                <MapPin className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                <p className="text-muted-foreground line-clamp-2">{result.address}</p>
              </div>

              {/* Contact Info */}
              <div className="flex flex-wrap gap-3 text-sm">
                {result.phone && result.phone !== "-" && (
                  <div className="flex items-center gap-1">
                    <Phone className="h-3 w-3 text-primary" />
                    <span className="text-muted-foreground">{result.phone}</span>
                  </div>
                )}
                {result.website && result.website !== "-" && (
                  <div className="flex items-center gap-1">
                    <Globe className="h-3 w-3 text-primary" />
                    <span className="text-muted-foreground truncate">Ada</span>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-sm text-muted-foreground">
              Halaman {currentPage} dari {totalPages}
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="flex-1 sm:flex-initial"
              >
                <ChevronLeft className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Sebelumnya</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="flex-1 sm:flex-initial"
              >
                <span className="hidden sm:inline">Selanjutnya</span>
                <ChevronRight className="h-4 w-4 sm:ml-2" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      <ResultDetailModal
        result={selectedResult}
        open={showDetailModal}
        onClose={() => setShowDetailModal(false)}
      />
    </>
  );
};
