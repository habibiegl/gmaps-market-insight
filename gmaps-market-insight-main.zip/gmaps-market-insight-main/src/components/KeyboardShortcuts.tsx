import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Keyboard } from "lucide-react";

interface ShortcutItem {
  key: string;
  description: string;
  action: () => void;
}

interface KeyboardShortcutsProps {
  onSearch?: () => void;
  onExport?: () => void;
  onFilter?: () => void;
  onRefresh?: () => void;
}

export const KeyboardShortcuts = ({
  onSearch,
  onExport,
  onFilter,
  onRefresh,
}: KeyboardShortcutsProps) => {
  const [open, setOpen] = useState(false);

  const shortcuts: ShortcutItem[] = [
    {
      key: "Ctrl+K",
      description: "Buka form pencarian",
      action: () => onSearch?.(),
    },
    {
      key: "Ctrl+E",
      description: "Export hasil",
      action: () => onExport?.(),
    },
    {
      key: "Ctrl+F",
      description: "Buka filter lanjutan",
      action: () => onFilter?.(),
    },
    {
      key: "Ctrl+R",
      description: "Refresh pencarian terakhir",
      action: () => onRefresh?.(),
    },
    {
      key: "Ctrl+/",
      description: "Tampilkan keyboard shortcuts",
      action: () => setOpen(true),
    },
  ];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Check if Ctrl (or Cmd on Mac) is pressed
      if (e.ctrlKey || e.metaKey) {
        // Find matching shortcut
        const shortcut = shortcuts.find((s) => {
          const key = s.key.split("+")[1].toLowerCase();
          return e.key.toLowerCase() === key;
        });

        if (shortcut) {
          e.preventDefault();
          shortcut.action();
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [shortcuts]);

  return (
    <>
      {/* Keyboard shortcut indicator */}
      <div className="fixed bottom-4 left-4 z-50">
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-2 px-3 py-2 bg-card border border-border rounded-lg shadow-lg hover:bg-muted transition-colors text-sm"
        >
          <Keyboard className="h-4 w-4" />
          <span className="hidden sm:inline">Keyboard Shortcuts</span>
          <Badge variant="secondary" className="text-xs">Ctrl+/</Badge>
        </button>
      </div>

      {/* Shortcuts Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Keyboard className="h-5 w-5" />
              Keyboard Shortcuts
            </DialogTitle>
            <DialogDescription>
              Gunakan shortcut ini untuk navigasi lebih cepat
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            {shortcuts.map((shortcut) => (
              <div
                key={shortcut.key}
                className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
              >
                <span className="text-sm">{shortcut.description}</span>
                <Badge variant="secondary" className="font-mono">
                  {shortcut.key}
                </Badge>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t">
            <p className="text-xs text-muted-foreground text-center">
              Tekan <strong>Ctrl+/</strong> kapan saja untuk membuka panduan ini
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
