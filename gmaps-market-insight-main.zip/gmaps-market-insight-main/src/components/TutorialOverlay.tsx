import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { HelpCircle, X, ChevronRight, ChevronLeft } from "lucide-react";

const tutorialSteps = [
  {
    title: "Selamat Datang! 👋",
    content: "Aplikasi ini membantu Anda melakukan riset kompetitor dan analisis market dengan scraping data Google Maps.",
  },
  {
    title: "1. Dapatkan API Key",
    content: "Daftar di SerpAPI (gratis 100 searches/bulan) dan ambil API key Anda di https://serpapi.com/manage-api-key",
  },
  {
    title: "2. Masukkan Parameter",
    content: "Isi kata kunci pencarian dan lokasi (Provinsi, Kota, Kecamatan). Contoh: 'Grosir Keripik' di 'Kota Malang, Jawa Timur'",
  },
  {
    title: "3. Filter & Analisis",
    content: "Setelah scraping, gunakan filter lanjutan untuk menyaring hasil berdasarkan rating, ulasan, atau kategori. Lihat analytics untuk visualisasi data.",
  },
  {
    title: "4. Export & Bookmark",
    content: "Export hasil ke Excel/CSV atau simpan ke bookmark untuk akses nanti. Semua pencarian otomatis tersimpan di history.",
  },
];

export const TutorialOverlay = () => {
  const [open, setOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [showHelp, setShowHelp] = useState(true);

  useEffect(() => {
    const hasSeenTutorial = localStorage.getItem('has_seen_tutorial');
    if (!hasSeenTutorial) {
      setTimeout(() => setOpen(true), 1000);
    }
  }, []);

  const handleClose = () => {
    setOpen(false);
    localStorage.setItem('has_seen_tutorial', 'true');
  };

  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleClose();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  if (!showHelp) return null;

  return (
    <>
      {/* Help Button */}
      <Button
        variant="outline"
        size="sm"
        className="fixed bottom-4 right-4 z-50 rounded-full h-12 w-12 p-0 shadow-lg"
        onClick={() => setOpen(true)}
      >
        <HelpCircle className="h-5 w-5" />
      </Button>

      {/* Tutorial Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogTitle className="sr-only">
            {tutorialSteps[currentStep].title}
          </DialogTitle>
          <DialogDescription className="sr-only">
            Panduan penggunaan aplikasi Google Maps Scraper
          </DialogDescription>
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-4 top-4"
            onClick={handleClose}
          >
            <X className="h-4 w-4" />
          </Button>

          <div className="pt-6">
            <div className="mb-6">
              <h2 className="text-2xl font-bold mb-2">
                {tutorialSteps[currentStep].title}
              </h2>
              <p className="text-muted-foreground">
                {tutorialSteps[currentStep].content}
              </p>
            </div>

            {/* Progress Dots */}
            <div className="flex justify-center gap-2 mb-6">
              {tutorialSteps.map((_, index) => (
                <div
                  key={index}
                  className={`h-2 rounded-full transition-all ${
                    index === currentStep
                      ? 'w-8 bg-primary'
                      : 'w-2 bg-muted'
                  }`}
                />
              ))}
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between gap-2">
              <Button
                variant="outline"
                onClick={prevStep}
                disabled={currentStep === 0}
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Sebelumnya
              </Button>
              <Button onClick={nextStep}>
                {currentStep === tutorialSteps.length - 1 ? 'Mulai' : 'Selanjutnya'}
                {currentStep < tutorialSteps.length - 1 && (
                  <ChevronRight className="h-4 w-4 ml-2" />
                )}
              </Button>
            </div>

            {/* Skip Button */}
            <Button
              variant="ghost"
              className="w-full mt-2"
              onClick={handleClose}
            >
              Lewati Tutorial
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
