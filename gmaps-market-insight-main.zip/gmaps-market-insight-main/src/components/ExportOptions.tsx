import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Download, FileSpreadsheet, FileText } from "lucide-react";
import { ScrapingResult } from "@/pages/Index";
import { useToast } from "@/hooks/use-toast";
import * as XLSX from "xlsx";

interface ExportOptionsProps {
  results: ScrapingResult[];
}

interface ColumnConfig {
  key: keyof ScrapingResult;
  label: string;
  checked: boolean;
}

export const ExportOptions = ({ results }: ExportOptionsProps) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [columns, setColumns] = useState<ColumnConfig[]>([
    { key: "name", label: "Nama", checked: true },
    { key: "address", label: "Alamat", checked: true },
    { key: "website", label: "Situs Web", checked: true },
    { key: "phone", label: "Telepon", checked: true },
    { key: "reviewCount", label: "Jumlah Ulasan", checked: true },
    { key: "rating", label: "Rating", checked: true },
    { key: "category", label: "Kategori", checked: true },
  ]);

  const toggleColumn = (key: keyof ScrapingResult) => {
    setColumns(prev =>
      prev.map(col => col.key === key ? { ...col, checked: !col.checked } : col)
    );
  };

  const exportToExcel = () => {
    if (results.length === 0) {
      toast({
        title: "Tidak Ada Data",
        description: "Tidak ada data untuk diexport",
        variant: "destructive",
      });
      return;
    }

    const selectedColumns = columns.filter(col => col.checked);
    const data = results.map(result => {
      const row: any = {};
      selectedColumns.forEach(col => {
        row[col.label] = result[col.key];
      });
      return row;
    });

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Data");
    XLSX.writeFile(workbook, `export-${Date.now()}.xlsx`);

    toast({
      title: "Export Berhasil",
      description: `${results.length} data berhasil diexport ke Excel`,
    });
    setOpen(false);
  };

  const exportToCSV = () => {
    if (results.length === 0) {
      toast({
        title: "Tidak Ada Data",
        description: "Tidak ada data untuk diexport",
        variant: "destructive",
      });
      return;
    }

    const selectedColumns = columns.filter(col => col.checked);
    
    // Create CSV header
    const header = selectedColumns.map(col => col.label).join(',');
    
    // Create CSV rows
    const rows = results.map(result => {
      return selectedColumns.map(col => {
        const value = result[col.key];
        // Escape commas and quotes
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      }).join(',');
    });

    const csv = [header, ...rows].join('\n');
    
    // Download CSV
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `export-${Date.now()}.csv`;
    link.click();

    toast({
      title: "Export Berhasil",
      description: `${results.length} data berhasil diexport ke CSV`,
    });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Export Lanjutan
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Pilih Kolom untuk Export</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-3">
            {columns.map((col) => (
              <div key={col.key} className="flex items-center space-x-2">
                <Checkbox
                  id={col.key}
                  checked={col.checked}
                  onCheckedChange={() => toggleColumn(col.key)}
                />
                <Label htmlFor={col.key} className="cursor-pointer">
                  {col.label}
                </Label>
              </div>
            ))}
          </div>

          <div className="flex gap-2 pt-4 border-t">
            <Button onClick={exportToExcel} className="flex-1 gap-2">
              <FileSpreadsheet className="h-4 w-4" />
              Export Excel
            </Button>
            <Button onClick={exportToCSV} variant="outline" className="flex-1 gap-2">
              <FileText className="h-4 w-4" />
              Export CSV
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
