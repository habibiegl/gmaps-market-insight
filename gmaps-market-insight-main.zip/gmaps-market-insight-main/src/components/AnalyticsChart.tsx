import { Card } from "@/components/ui/card";
import { ScrapingResult } from "@/pages/Index";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { TrendingUp } from "lucide-react";

interface AnalyticsChartProps {
  results: ScrapingResult[];
}

const COLORS = ['#3b82f6', '#06b6d4', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'];

export const AnalyticsChart = ({ results }: AnalyticsChartProps) => {
  // Rating distribution
  const ratingDistribution = [
    { name: "1-2 ⭐", count: results.filter(r => r.rating >= 1 && r.rating < 2).length },
    { name: "2-3 ⭐", count: results.filter(r => r.rating >= 2 && r.rating < 3).length },
    { name: "3-4 ⭐", count: results.filter(r => r.rating >= 3 && r.rating < 4).length },
    { name: "4-5 ⭐", count: results.filter(r => r.rating >= 4).length },
  ].filter(d => d.count > 0);

  // Category distribution
  const categoryCount = results.reduce((acc, r) => {
    const cat = r.category || "Tidak Tersedia";
    acc[cat] = (acc[cat] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const categoryData = Object.entries(categoryCount)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 6);

  // Average stats
  const avgRating = (results.reduce((sum, r) => sum + r.rating, 0) / results.length).toFixed(1);
  const avgReviews = Math.round(results.reduce((sum, r) => sum + r.reviewCount, 0) / results.length);
  const withWebsite = results.filter(r => r.website && r.website !== "-").length;
  const websitePercentage = ((withWebsite / results.length) * 100).toFixed(0);

  return (
    <div className="space-y-4">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Total Hasil</div>
          <div className="text-2xl font-bold text-primary">{results.length}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Rating Rata-Rata</div>
          <div className="text-2xl font-bold text-primary">⭐ {avgRating}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Ulasan Rata-Rata</div>
          <div className="text-2xl font-bold text-primary">{avgReviews.toLocaleString()}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-muted-foreground">Punya Website</div>
          <div className="text-2xl font-bold text-primary">{websitePercentage}%</div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Rating Distribution */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h3 className="font-semibold">Distribusi Rating</h3>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={ratingDistribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#3b82f6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Category Distribution */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h3 className="font-semibold">Top Kategori</h3>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
};
