import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Folder, Plus, Trash2, FolderOpen, Pencil } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ScrapingResult } from "@/pages/Index";

interface FolderManagerProps {
  selectedResults?: ScrapingResult[];
  onMoveToFolder?: () => void;
}

interface FolderType {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  created_at: string;
  itemCount?: number;
}

export const FolderManager = ({ selectedResults, onMoveToFolder }: FolderManagerProps) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [folders, setFolders] = useState<FolderType[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newFolder, setNewFolder] = useState({
    name: "",
    description: "",
    color: "#3b82f6",
    icon: "folder",
  });

  useEffect(() => {
    if (open) {
      loadFolders();
    }
  }, [open]);

  const loadFolders = async () => {
    try {
      const { data, error } = await supabase
        .from('folders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Get item counts for each folder
      const foldersWithCounts = await Promise.all(
        (data || []).map(async (folder) => {
          const { count } = await supabase
            .from('folder_items')
            .select('*', { count: 'exact', head: true })
            .eq('folder_id', folder.id);

          return { ...folder, itemCount: count || 0 };
        })
      );

      setFolders(foldersWithCounts);
    } catch (error) {
      console.error('Error loading folders:', error);
      toast({
        title: "Error Loading Folders",
        description: "Gagal memuat folders",
        variant: "destructive",
      });
    }
  };

  const createFolder = async () => {
    if (!newFolder.name.trim()) {
      toast({
        title: "Nama Required",
        description: "Masukkan nama folder",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('folders')
        .insert([newFolder]);

      if (error) throw error;

      toast({
        title: "Folder Created",
        description: `Folder "${newFolder.name}" berhasil dibuat`,
      });

      setNewFolder({ name: "", description: "", color: "#3b82f6", icon: "folder" });
      setIsCreating(false);
      loadFolders();
    } catch (error) {
      console.error('Error creating folder:', error);
      toast({
        title: "Error",
        description: "Gagal membuat folder",
        variant: "destructive",
      });
    }
  };

  const deleteFolder = async (id: string, name: string) => {
    if (!confirm(`Hapus folder "${name}"? Semua items di folder ini akan dihapus.`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('folders')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Folder Deleted",
        description: `Folder "${name}" berhasil dihapus`,
      });

      loadFolders();
    } catch (error) {
      console.error('Error deleting folder:', error);
      toast({
        title: "Error",
        description: "Gagal menghapus folder",
        variant: "destructive",
      });
    }
  };

  const moveResultsToFolder = async (folderId: string) => {
    if (!selectedResults || selectedResults.length === 0) {
      toast({
        title: "No Selection",
        description: "Pilih results terlebih dahulu",
        variant: "destructive",
      });
      return;
    }

    try {
      const items = selectedResults.map(result => ({
        folder_id: folderId,
        place_id: result.id,
      }));

      const { error } = await supabase
        .from('folder_items')
        .insert(items);

      if (error) throw error;

      toast({
        title: "Success",
        description: `${selectedResults.length} items dipindahkan ke folder`,
      });

      onMoveToFolder?.();
      setOpen(false);
    } catch (error: any) {
      console.error('Error moving to folder:', error);
      
      if (error.code === '23505') {
        toast({
          title: "Already in Folder",
          description: "Beberapa items sudah ada di folder ini",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Gagal memindahkan items",
          variant: "destructive",
        });
      }
    }
  };

  const colorOptions = [
    { value: "#3b82f6", label: "Blue" },
    { value: "#10b981", label: "Green" },
    { value: "#f59e0b", label: "Orange" },
    { value: "#ef4444", label: "Red" },
    { value: "#8b5cf6", label: "Purple" },
    { value: "#ec4899", label: "Pink" },
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Folder className="h-4 w-4" />
          Folders ({folders.length})
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Folder Manager</DialogTitle>
          <DialogDescription>
            Organize hasil scraping ke dalam folders
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Create New Folder */}
          {!isCreating ? (
            <Button onClick={() => setIsCreating(true)} variant="outline" className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              New Folder
            </Button>
          ) : (
            <div className="p-4 border rounded-lg space-y-3">
              <div>
                <Label>Folder Name</Label>
                <Input
                  placeholder="e.g., Kompetitor Jakarta"
                  value={newFolder.name}
                  onChange={(e) => setNewFolder({ ...newFolder, name: e.target.value })}
                />
              </div>
              <div>
                <Label>Description (Optional)</Label>
                <Textarea
                  placeholder="Deskripsi folder..."
                  value={newFolder.description}
                  onChange={(e) => setNewFolder({ ...newFolder, description: e.target.value })}
                  rows={2}
                />
              </div>
              <div>
                <Label>Color</Label>
                <Select value={newFolder.color} onValueChange={(value) => setNewFolder({ ...newFolder, color: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {colorOptions.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 rounded" style={{ backgroundColor: option.value }} />
                          {option.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Button onClick={createFolder} className="flex-1">Create</Button>
                <Button onClick={() => setIsCreating(false)} variant="outline">Cancel</Button>
              </div>
            </div>
          )}

          {/* Folders List */}
          <ScrollArea className="h-[400px]">
            {folders.length === 0 ? (
              <div className="text-center py-12">
                <FolderOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Belum ada folder</p>
              </div>
            ) : (
              <div className="space-y-2">
                {folders.map((folder) => (
                  <div
                    key={folder.id}
                    className="p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1">
                        <div
                          className="h-10 w-10 rounded-lg flex items-center justify-center mt-1"
                          style={{ backgroundColor: `${folder.color}20` }}
                        >
                          <Folder style={{ color: folder.color }} className="h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium">{folder.name}</h4>
                          {folder.description && (
                            <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                              {folder.description}
                            </p>
                          )}
                          <p className="text-xs text-muted-foreground mt-2">
                            {folder.itemCount || 0} items
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {selectedResults && selectedResults.length > 0 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => moveResultsToFolder(folder.id)}
                          >
                            Add {selectedResults.length} items
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:text-destructive"
                          onClick={() => deleteFolder(folder.id, folder.name)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
};
