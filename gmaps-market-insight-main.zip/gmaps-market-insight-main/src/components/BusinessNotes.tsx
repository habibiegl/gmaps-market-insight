import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { StickyNote, Plus, Trash2, Edit2, Save } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface BusinessNotesProps {
  placeId: string;
  businessName: string;
}

interface NoteType {
  id: string;
  note: string;
  created_at: string;
  updated_at: string;
}

export const BusinessNotes = ({ placeId, businessName }: BusinessNotesProps) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [notes, setNotes] = useState<NoteType[]>([]);
  const [newNote, setNewNote] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");

  useEffect(() => {
    if (open) {
      loadNotes();
    }
  }, [open, placeId]);

  const loadNotes = async () => {
    try {
      const { data, error } = await supabase
        .from('business_notes')
        .select('*')
        .eq('place_id', placeId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNotes(data || []);
    } catch (error) {
      console.error('Error loading notes:', error);
    }
  };

  const addNote = async () => {
    if (!newNote.trim()) {
      toast({
        title: "Empty Note",
        description: "Tulis catatan terlebih dahulu",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('business_notes')
        .insert([{ place_id: placeId, note: newNote.trim() }]);

      if (error) throw error;

      toast({
        title: "Note Added",
        description: "Catatan berhasil ditambahkan",
      });

      setNewNote("");
      loadNotes();
    } catch (error) {
      console.error('Error adding note:', error);
      toast({
        title: "Error",
        description: "Gagal menambahkan catatan",
        variant: "destructive",
      });
    }
  };

  const updateNote = async (id: string) => {
    if (!editText.trim()) return;

    try {
      const { error } = await supabase
        .from('business_notes')
        .update({ note: editText.trim() })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Note Updated",
        description: "Catatan berhasil diupdate",
      });

      setEditingId(null);
      setEditText("");
      loadNotes();
    } catch (error) {
      console.error('Error updating note:', error);
      toast({
        title: "Error",
        description: "Gagal update catatan",
        variant: "destructive",
      });
    }
  };

  const deleteNote = async (id: string) => {
    try {
      const { error } = await supabase
        .from('business_notes')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Note Deleted",
        description: "Catatan berhasil dihapus",
      });

      loadNotes();
    } catch (error) {
      console.error('Error deleting note:', error);
      toast({
        title: "Error",
        description: "Gagal menghapus catatan",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2">
          <StickyNote className="h-3 w-3" />
          Notes ({notes.length})
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Notes - {businessName}</DialogTitle>
          <DialogDescription>
            Tambah catatan pribadi tentang bisnis ini
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Add New Note */}
          <div className="space-y-2">
            <Textarea
              placeholder="Tulis catatan baru..."
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              rows={3}
            />
            <Button onClick={addNote} className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add Note
            </Button>
          </div>

          {/* Notes List */}
          <ScrollArea className="h-[400px]">
            {notes.length === 0 ? (
              <div className="text-center py-12">
                <StickyNote className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Belum ada catatan</p>
              </div>
            ) : (
              <div className="space-y-3">
                {notes.map((note) => (
                  <div
                    key={note.id}
                    className="p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                  >
                    {editingId === note.id ? (
                      <div className="space-y-2">
                        <Textarea
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          rows={3}
                        />
                        <div className="flex gap-2">
                          <Button onClick={() => updateNote(note.id)} size="sm">
                            <Save className="h-3 w-3 mr-2" />
                            Save
                          </Button>
                          <Button
                            onClick={() => {
                              setEditingId(null);
                              setEditText("");
                            }}
                            variant="outline"
                            size="sm"
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <p className="text-sm whitespace-pre-wrap">{note.note}</p>
                        <div className="flex items-center justify-between mt-3 pt-3 border-t">
                          <span className="text-xs text-muted-foreground">
                            {new Date(note.updated_at).toLocaleString('id-ID')}
                          </span>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setEditingId(note.id);
                                setEditText(note.note);
                              }}
                            >
                              <Edit2 className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-destructive hover:text-destructive"
                              onClick={() => deleteNote(note.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
};
