import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Brain, AlertTriangle, TrendingUp, Sparkles, Loader2 } from "lucide-react";
import { ScrapingResult } from "@/pages/Index";
import { useToast } from "@/hooks/use-toast";

interface AIInsightsProps {
  results: ScrapingResult[];
}

interface Insight {
  type: 'anomaly' | 'opportunity' | 'warning' | 'insight';
  title: string;
  description: string;
  businesses: string[];
}

export const AIInsights = ({ results }: AIInsightsProps) => {
  const { toast } = useToast();
  const [insights, setInsights] = useState<Insight[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeResults = () => {
    if (results.length === 0) {
      toast({
        title: "No Data",
        description: "Tidak ada data untuk dianalisa",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);

    setTimeout(() => {
      const generatedInsights: Insight[] = [];

      // 1. Anomaly Detection - Unusually high ratings with low reviews
      const suspiciouslyHigh = results.filter(
        r => r.rating >= 4.9 && r.reviewCount < 5
      );
      if (suspiciouslyHigh.length > 0) {
        generatedInsights.push({
          type: 'anomaly',
          title: 'Rating Mencurigakan',
          description: `${suspiciouslyHigh.length} bisnis dengan rating sangat tinggi tapi ulasan sedikit`,
          businesses: suspiciouslyHigh.map(r => r.name),
        });
      }

      // 2. Opportunity - High reviews but medium rating (room for improvement)
      const opportunityTargets = results.filter(
        r => r.reviewCount > 50 && r.rating >= 3.5 && r.rating < 4.5
      );
      if (opportunityTargets.length > 0) {
        generatedInsights.push({
          type: 'opportunity',
          title: 'Opportunity Target',
          description: `${opportunityTargets.length} bisnis established dengan ruang untuk improve`,
          businesses: opportunityTargets.slice(0, 5).map(r => r.name),
        });
      }

      // 3. Market Leaders - Very high rating + high reviews
      const marketLeaders = results.filter(
        r => r.rating >= 4.5 && r.reviewCount >= 50
      );
      if (marketLeaders.length > 0) {
        generatedInsights.push({
          type: 'insight',
          title: 'Market Leaders',
          description: `${marketLeaders.length} bisnis top performer di market ini`,
          businesses: marketLeaders.slice(0, 5).map(r => r.name),
        });
      }

      // 4. No Website Warning - Missing online presence
      const noWebsite = results.filter(
        r => (!r.website || r.website === '-') && r.rating >= 4.0
      );
      if (noWebsite.length > 0) {
        generatedInsights.push({
          type: 'warning',
          title: 'Missing Online Presence',
          description: `${noWebsite.length} bisnis bagus tanpa website (opportunity untuk outreach)`,
          businesses: noWebsite.slice(0, 5).map(r => r.name),
        });
      }

      // 5. Underdog Detection - Low reviews but high rating
      const underdogs = results.filter(
        r => r.rating >= 4.7 && r.reviewCount >= 10 && r.reviewCount < 30
      );
      if (underdogs.length > 0) {
        generatedInsights.push({
          type: 'opportunity',
          title: 'Hidden Gems',
          description: `${underdogs.length} bisnis berkualitas tinggi yang belum populer`,
          businesses: underdogs.map(r => r.name),
        });
      }

      // 6. Category Saturation
      const categoryCount = new Map<string, number>();
      results.forEach(r => {
        categoryCount.set(r.category, (categoryCount.get(r.category) || 0) + 1);
      });
      
      const saturatedCategories = Array.from(categoryCount.entries())
        .filter(([_, count]) => count > results.length * 0.3);
      
      if (saturatedCategories.length > 0) {
        generatedInsights.push({
          type: 'insight',
          title: 'Market Saturation',
          description: `Kategori ${saturatedCategories.map(c => c[0]).join(', ')} sangat kompetitif`,
          businesses: [],
        });
      }

      setInsights(generatedInsights);
      setIsAnalyzing(false);

      toast({
        title: "Analysis Complete",
        description: `${generatedInsights.length} insights ditemukan`,
      });
    }, 1500);
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'anomaly': return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'opportunity': return <TrendingUp className="h-5 w-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      default: return <Sparkles className="h-5 w-5 text-blue-500" />;
    }
  };

  const getInsightBadgeVariant = (type: string) => {
    switch (type) {
      case 'anomaly': return 'destructive';
      case 'opportunity': return 'default';
      case 'warning': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">AI Insights</h3>
        </div>
        <Button
          onClick={analyzeResults}
          disabled={isAnalyzing || results.length === 0}
          className="gap-2"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Brain className="h-4 w-4" />
              Analyze Market
            </>
          )}
        </Button>
      </div>

      {insights.length === 0 ? (
        <div className="text-center py-12">
          <Brain className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
          <p className="text-muted-foreground">
            Klik "Analyze Market" untuk mendapatkan AI-powered insights
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Deteksi anomali, opportunity, dan competitive insights
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {insights.map((insight, index) => (
            <div key={index} className="p-4 rounded-lg border bg-card">
              <div className="flex items-start gap-3">
                {getInsightIcon(insight.type)}
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-semibold">{insight.title}</h4>
                    <Badge variant={getInsightBadgeVariant(insight.type)}>
                      {insight.type}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    {insight.description}
                  </p>
                  {insight.businesses.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {insight.businesses.slice(0, 5).map((business, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {business}
                        </Badge>
                      ))}
                      {insight.businesses.length > 5 && (
                        <Badge variant="outline" className="text-xs">
                          +{insight.businesses.length - 5} more
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};
