import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Filter, RotateCcw } from "lucide-react";

export interface FilterOptions {
  minRating: number;
  minReviews: number;
  hasWebsite: string;
  category: string;
  searchTerm: string;
}

interface AdvancedFiltersProps {
  onFilterChange: (filters: FilterOptions) => void;
  categories: string[];
}

export const AdvancedFilters = ({ onFilterChange, categories }: AdvancedFiltersProps) => {
  const [filters, setFilters] = useState<FilterOptions>({
    minRating: 0,
    minReviews: 0,
    hasWebsite: "all",
    category: "all",
    searchTerm: "",
  });

  const handleFilterUpdate = (key: keyof FilterOptions, value: string | number) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const handleReset = () => {
    const resetFilters: FilterOptions = {
      minRating: 0,
      minReviews: 0,
      hasWebsite: "all",
      category: "all",
      searchTerm: "",
    };
    setFilters(resetFilters);
    onFilterChange(resetFilters);
  };

  return (
    <Card className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-primary" />
          <h3 className="font-semibold">Filter Lanjutan</h3>
        </div>
        <Button variant="ghost" size="sm" onClick={handleReset}>
          <RotateCcw className="h-4 w-4 mr-2" />
          Reset
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="searchTerm" className="text-sm">Cari Nama/Alamat</Label>
          <Input
            id="searchTerm"
            placeholder="Cari..."
            value={filters.searchTerm}
            onChange={(e) => handleFilterUpdate("searchTerm", e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="minRating" className="text-sm">Rating Minimal</Label>
          <Select
            value={filters.minRating.toString()}
            onValueChange={(value) => handleFilterUpdate("minRating", parseFloat(value))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="0">Semua Rating</SelectItem>
              <SelectItem value="3.0">⭐ 3.0+</SelectItem>
              <SelectItem value="3.5">⭐ 3.5+</SelectItem>
              <SelectItem value="4.0">⭐ 4.0+</SelectItem>
              <SelectItem value="4.5">⭐ 4.5+</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="minReviews" className="text-sm">Ulasan Minimal</Label>
          <Select
            value={filters.minReviews.toString()}
            onValueChange={(value) => handleFilterUpdate("minReviews", parseInt(value))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="0">Semua</SelectItem>
              <SelectItem value="10">10+ ulasan</SelectItem>
              <SelectItem value="50">50+ ulasan</SelectItem>
              <SelectItem value="100">100+ ulasan</SelectItem>
              <SelectItem value="500">500+ ulasan</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="category" className="text-sm">Kategori</Label>
          <Select
            value={filters.category}
            onValueChange={(value) => handleFilterUpdate("category", value)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Kategori</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="hasWebsite" className="text-sm">Website</Label>
          <Select
            value={filters.hasWebsite}
            onValueChange={(value) => handleFilterUpdate("hasWebsite", value)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua</SelectItem>
              <SelectItem value="yes">Ada Website</SelectItem>
              <SelectItem value="no">Tidak Ada Website</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </Card>
  );
};
