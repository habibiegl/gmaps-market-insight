import { useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Filter, X } from "lucide-react";
import { FilterOptions } from "./AdvancedFilters";

interface MobileFilterSheetProps {
  onFilterChange: (filters: FilterOptions) => void;
  categories: string[];
}

export const MobileFilterSheet = ({ onFilterChange, categories }: MobileFilterSheetProps) => {
  const [open, setOpen] = useState(false);
  const [filters, setFilters] = useState<FilterOptions>({
    minRating: 0,
    minReviews: 0,
    hasWebsite: "all",
    category: "all",
    searchTerm: "",
  });

  const handleApplyFilters = () => {
    onFilterChange(filters);
    setOpen(false);
  };

  const handleResetFilters = () => {
    const resetFilters: FilterOptions = {
      minRating: 0,
      minReviews: 0,
      hasWebsite: "all",
      category: "all",
      searchTerm: "",
    };
    setFilters(resetFilters);
    onFilterChange(resetFilters);
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="md:hidden">
          <Filter className="h-4 w-4 mr-2" />
          Filter
        </Button>
      </SheetTrigger>
      <SheetContent side="bottom" className="h-[80vh]">
        <SheetHeader>
          <SheetTitle>Advanced Filters</SheetTitle>
          <SheetDescription>
            Filter hasil pencarian berdasarkan kriteria
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-6 mt-6 overflow-y-auto max-h-[calc(80vh-180px)]">
          {/* Search Term */}
          <div>
            <Label>Cari dalam hasil</Label>
            <Input
              placeholder="Nama atau alamat..."
              value={filters.searchTerm}
              onChange={(e) => setFilters({ ...filters, searchTerm: e.target.value })}
              className="mt-2"
            />
          </div>

          {/* Min Rating */}
          <div>
            <Label>Rating Minimum: {filters.minRating.toFixed(1)}</Label>
            <Slider
              value={[filters.minRating]}
              onValueChange={(value) => setFilters({ ...filters, minRating: value[0] })}
              max={5}
              step={0.1}
              className="mt-3"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>0.0</span>
              <span>5.0</span>
            </div>
          </div>

          {/* Min Reviews */}
          <div>
            <Label>Minimum Ulasan: {filters.minReviews}</Label>
            <Slider
              value={[filters.minReviews]}
              onValueChange={(value) => setFilters({ ...filters, minReviews: value[0] })}
              max={500}
              step={10}
              className="mt-3"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>0</span>
              <span>500+</span>
            </div>
          </div>

          {/* Has Website */}
          <div>
            <Label>Website</Label>
            <Select
              value={filters.hasWebsite}
              onValueChange={(value) => setFilters({ ...filters, hasWebsite: value as any })}
            >
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua</SelectItem>
                <SelectItem value="yes">Ada Website</SelectItem>
                <SelectItem value="no">Tidak Ada Website</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Category */}
          {categories.length > 0 && (
            <div>
              <Label>Kategori</Label>
              <Select
                value={filters.category}
                onValueChange={(value) => setFilters({ ...filters, category: value })}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Kategori</SelectItem>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t bg-background flex gap-2">
          <Button
            variant="outline"
            onClick={handleResetFilters}
            className="flex-1"
          >
            <X className="h-4 w-4 mr-2" />
            Reset
          </Button>
          <Button
            onClick={handleApplyFilters}
            className="flex-1"
          >
            Apply Filters
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};
