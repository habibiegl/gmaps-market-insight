import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { apiKey, keyword, province, city, district } = await req.json();

    console.log('Starting Google Maps scraping with params:', { keyword, province, city, district });

    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'API Key is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Build query string
    let query = keyword;
    if (district) {
      query += ` ${district}`;
    }
    if (city) {
      query += ` ${city}`;
    }
    if (province) {
      query += ` ${province}`;
    }
    query += ' Indonesia';

    console.log('Search query:', query);

    // Call SerpAPI using Google Maps engine
    // Documentation: https://serpapi.com/google-maps-api
    const serpApiUrl = new URL('https://serpapi.com/search');
    serpApiUrl.searchParams.append('engine', 'google_maps');
    serpApiUrl.searchParams.append('q', query);
    serpApiUrl.searchParams.append('api_key', apiKey);
    serpApiUrl.searchParams.append('hl', 'id');
    serpApiUrl.searchParams.append('gl', 'id');
    serpApiUrl.searchParams.append('type', 'search');
    
    console.log('Calling SerpAPI:', serpApiUrl.toString().replace(apiKey, '***'));

    const response = await fetch(serpApiUrl.toString(), {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('SerpAPI error:', response.status, errorText);
      
      if (response.status === 401 || response.status === 403) {
        return new Response(
          JSON.stringify({ 
            error: 'API Key tidak valid',
            details: 'Mohon periksa kembali API Key SerpAPI Anda. Dapatkan di: https://serpapi.com/manage-api-key'
          }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (response.status === 429) {
        return new Response(
          JSON.stringify({ 
            error: 'Quota API Habis',
            details: 'Free tier SerpAPI Anda sudah habis (100 searches/bulan). Upgrade di: https://serpapi.com/pricing'
          }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ 
          error: `Error dari SerpAPI: ${response.status}`,
          details: errorText
        }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const data = await response.json();
    console.log('SerpAPI response received, processing data...');

    // Transform SerpAPI data to our format
    const results = [];
    
    // SerpAPI returns results in "local_results" array
    if (data.local_results && Array.isArray(data.local_results)) {
      for (const item of data.local_results) {
        results.push({
          id: item.place_id || item.data_cid || Math.random().toString(36).substr(2, 9),
          name: item.title || '-',
          address: item.address || '-',
          website: item.website || '-',
          phone: item.phone || '-',
          reviewCount: item.reviews || 0,
          rating: item.rating || 0,
          category: item.type || 'Tidak Tersedia',
        });
      }
    }

    console.log(`Successfully processed ${results.length} results`);

    return new Response(
      JSON.stringify({ 
        success: true,
        results,
        count: results.length 
      }),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in google-maps-scraper function:', error);
    const errorMessage = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
