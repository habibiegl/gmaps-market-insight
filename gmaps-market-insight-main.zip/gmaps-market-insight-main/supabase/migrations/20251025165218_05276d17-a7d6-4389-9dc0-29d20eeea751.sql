-- Create table for search history
CREATE TABLE IF NOT EXISTS public.search_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  keyword TEXT NOT NULL,
  province TEXT NOT NULL,
  city TEXT NOT NULL,
  district TEXT,
  results_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create table for scraping results
CREATE TABLE IF NOT EXISTS public.scraping_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  search_id UUID REFERENCES public.search_history(id) ON DELETE CASCADE,
  place_id TEXT,
  name TEXT NOT NULL,
  address TEXT,
  website TEXT,
  phone TEXT,
  review_count INTEGER DEFAULT 0,
  rating DECIMAL(2,1) DEFAULT 0,
  category TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.search_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scraping_results ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (since no auth yet)
CREATE POLICY "Allow public read access on search_history"
  ON public.search_history
  FOR SELECT
  USING (true);

CREATE POLICY "Allow public insert access on search_history"
  ON public.search_history
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow public delete access on search_history"
  ON public.search_history
  FOR DELETE
  USING (true);

CREATE POLICY "Allow public read access on scraping_results"
  ON public.scraping_results
  FOR SELECT
  USING (true);

CREATE POLICY "Allow public insert access on scraping_results"
  ON public.scraping_results
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow public delete access on scraping_results"
  ON public.scraping_results
  FOR DELETE
  USING (true);

-- Create indexes for better performance
CREATE INDEX idx_search_history_created_at ON public.search_history(created_at DESC);
CREATE INDEX idx_scraping_results_search_id ON public.scraping_results(search_id);
CREATE INDEX idx_scraping_results_rating ON public.scraping_results(rating DESC);
CREATE INDEX idx_scraping_results_review_count ON public.scraping_results(review_count DESC);