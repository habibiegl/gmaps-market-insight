-- Create folders table
CREATE TABLE public.folders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  color TEXT DEFAULT '#3b82f6',
  icon TEXT DEFAULT 'folder',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create tags table
CREATE TABLE public.tags (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  color TEXT DEFAULT '#10b981',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create notes table for business results
CREATE TABLE public.business_notes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  place_id TEXT NOT NULL,
  note TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create folder_items junction table
CREATE TABLE public.folder_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  folder_id UUID NOT NULL REFERENCES public.folders(id) ON DELETE CASCADE,
  place_id TEXT NOT NULL,
  added_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(folder_id, place_id)
);

-- Create result_tags junction table
CREATE TABLE public.result_tags (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  place_id TEXT NOT NULL,
  tag_id UUID NOT NULL REFERENCES public.tags(id) ON DELETE CASCADE,
  tagged_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(place_id, tag_id)
);

-- Create favorites table
CREATE TABLE public.favorites (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  place_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  address TEXT,
  rating NUMERIC,
  review_count INTEGER,
  category TEXT,
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  status TEXT DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'interested', 'closed', 'archived')),
  favorited_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_contacted TIMESTAMP WITH TIME ZONE
);

-- Enable Row Level Security
ALTER TABLE public.folders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.folder_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.result_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (since we don't have auth yet)
CREATE POLICY "Allow public read access on folders" ON public.folders FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on folders" ON public.folders FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access on folders" ON public.folders FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access on folders" ON public.folders FOR DELETE USING (true);

CREATE POLICY "Allow public read access on tags" ON public.tags FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on tags" ON public.tags FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public delete access on tags" ON public.tags FOR DELETE USING (true);

CREATE POLICY "Allow public read access on business_notes" ON public.business_notes FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on business_notes" ON public.business_notes FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access on business_notes" ON public.business_notes FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access on business_notes" ON public.business_notes FOR DELETE USING (true);

CREATE POLICY "Allow public read access on folder_items" ON public.folder_items FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on folder_items" ON public.folder_items FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public delete access on folder_items" ON public.folder_items FOR DELETE USING (true);

CREATE POLICY "Allow public read access on result_tags" ON public.result_tags FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on result_tags" ON public.result_tags FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public delete access on result_tags" ON public.result_tags FOR DELETE USING (true);

CREATE POLICY "Allow public read access on favorites" ON public.favorites FOR SELECT USING (true);
CREATE POLICY "Allow public insert access on favorites" ON public.favorites FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access on favorites" ON public.favorites FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access on favorites" ON public.favorites FOR DELETE USING (true);

-- Create indexes for better performance
CREATE INDEX idx_folder_items_folder_id ON public.folder_items(folder_id);
CREATE INDEX idx_folder_items_place_id ON public.folder_items(place_id);
CREATE INDEX idx_result_tags_place_id ON public.result_tags(place_id);
CREATE INDEX idx_result_tags_tag_id ON public.result_tags(tag_id);
CREATE INDEX idx_business_notes_place_id ON public.business_notes(place_id);
CREATE INDEX idx_favorites_place_id ON public.favorites(place_id);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for timestamp updates
CREATE TRIGGER update_folders_updated_at
BEFORE UPDATE ON public.folders
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_business_notes_updated_at
BEFORE UPDATE ON public.business_notes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();